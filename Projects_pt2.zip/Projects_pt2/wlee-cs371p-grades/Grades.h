// --------------------------------
// Grades
// February 2012
// Author: Wonjun Lee
// --------------------------------

/*

To configure Doxygen:
% doxygen -g
That creates the file "Doxyfile".
Make the following edits:
EXTRACT_ALL = YES
EXTRACT_PRIVATE = YES
EXTRACT_STATIC = YES
GENERATE_LATEX = NO

To document the program:
% doxygen Doxyfile

*/

// --------
// includes
// --------

#include <cassert> // assert
#include <iostream> // endl, istream, ostream
#include <string>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <ctime>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <ios>
#include <algorithm>
#include <cmath>
#include <iomanip>


using namespace std;

#define DOUBLE_max std::numeric_limits<double>::max()

int numEvents; // the number of events (a positive int)
vector<int> ceilings; // the myMax values of the events (several positive ints)
vector<int> weights; // the weights of the events (several positive ints) [that add up to 100]
int size; // the number of students (a positive int)
double myMax; // the myMax of the total scores as a percent (a non-negative double) [rounded to two decimal places]
double myMean; // the myMean of the total scores as a percent (a non-negative double) [rounded to two decimal places]
double myMin; // the myMin of the total scores as a percent (a non-negative double) [rounded to two decimal places]

int numAGetters; 
int numBGetters; 
int numCGetters; 
int numDGetters; 
int numFGetters; 

double percAGetters; 
double percBGetters; 
double percCGetters; 
double percDGetters; 
double percFGetters; 
    
double gpa; // the GPA of the whole class (a non-negative double) (A = 4pts, B = 3pts, C = 2pts, D = 1pt, F = 0pts)

// -------
// Student
// -------

/**
* A student object with the necessary information to organize a grade report.
*/

struct Student {
    string id; /**< a 5-char String */
    int unique; /**< a 5-digit positive int */
    string taName; /**< a myMax 8-char String */
    vector<int> scores; /**< several non-negative ints [<= to the corresponding myMax value] {formatted to the correct width} */
    
    double totalScore; /**< the total score as a percent (a non-negative double) [rounded to two decimal places] */
    double zScore; /**< the z-score (a double) [rounded to two decimal places] */
    char letterGrade; /**< the letter grade (a char) */
    
   
    Student(){
    
    };
    
    Student(string _id, int _unique, string _taName, vector<int> _scores, double _totalScore, double _zScore, char _letterGrade){
        id = _id;
        unique = _unique;
        taName = _taName;
        scores = _scores;
        totalScore = _totalScore;
        zScore = _zScore;
        letterGrade = _letterGrade;
    };
    
    bool operator< (Student other) const { /** determines which of two students is "greater" for sorting. */
        if(this->totalScore == other.totalScore){
            return ((this->id) < (other.id));
        }
        else{
            return ((this->totalScore) > (other.totalScore));
        }
    }
};

vector<Student> students;


// ----------------------
// grades_processStudents
// ----------------------

/**
* computes the max, mean, min, standard deviation, and z-scores of a class.
* @param students a vector of Student objects
*/

void grades_processStudents(vector<Student> &students){
    /*
    double myMin = 100; 
    double myMean;
    double myMax = 0;
    double stddev = 0;
    */
    
    myMax = 0.0;
    myMean = 0.0;
    myMin = 100.0;
    double tempMax;
    double tempMin;
    for(int i=0;i<size;i++){ // compute the max, mean and min
        tempMax = students[i].totalScore;
        tempMin = students[i].totalScore;
        myMean += students[i].totalScore;
        if(tempMax > myMax){
            myMax = tempMax;
        }
        if(tempMin < myMin){
            myMin = tempMin;
        }
    }
    myMean /= size;
    myMean = floor((myMean*100)+0.5)/100.0; 
    
    double stddev = 0;
    double temp;
    
    for(int i=0;i<(int)(students.size());i++){ // compute the standard deviation
        temp = students[i].totalScore - myMean;
        temp *= temp;
        stddev += temp;
    }
    
    stddev /= numEvents;
    stddev = sqrt(stddev);
    
    for(int i=0;i<(int)(students.size());i++){ // compute the z-scores
        if(stddev == 0)
            students[i].zScore = 0; // Be careful not to divide by zero!
        else{
            double d = (students[i].totalScore - myMean)/stddev;
            students[i].zScore = floor((d*100)+0.5)/100.0;
        }
    }
    
}

// ------------
// grades_print
// ------------

/**
* prints the grade reports of the classes. All the global variables must be assigned values.
*/

void grades_print(ostream& stream){
    grades_processStudents(students);
    stream << "Events" << endl;
    stream <<  "------" << endl;
    stream <<  numEvents << endl << endl;
    stream << "Max Values" << endl;
    stream << "----------" << endl;
    // print the ceilings
    vector<int>::iterator iter = ceilings.begin();
    
    stream << *(iter++);
    while(iter != ceilings.end()){
        stream << " " << *(iter++);                
    }
    
    stream << endl << endl <<  "Weights" << endl;
    stream <<  "-------" << endl;
    // print the weights
    
    iter = weights.begin();
    
    stream << *(iter++);
    while(iter != weights.end()){
        stream << " " << *(iter++);                
    }
    
    stream << endl << endl <<  "Statistics" << endl;
    stream <<  "----------" << endl;
    stream << "Size = " << size << endl << endl;    
    stream << "Max = " << myMax << "%" << endl;
    stream << "Mean = " << myMean << "%" << endl;
    stream << "Min = " << myMin << "%" << endl << endl;
    
    percAGetters = 100.0 * (double)numAGetters / (double)size;
    percAGetters =  floor((percAGetters*100)+0.5)/100.0;  
    percBGetters = 100.0 * (double)numBGetters / (double)size;
    percBGetters =  floor((percBGetters*100)+0.5)/100.0;  
    percCGetters = 100.0 * (double)numCGetters / (double)size;  
    percCGetters =  floor((percCGetters*100)+0.5)/100.0; 
    percDGetters = 100.0 * (double)numDGetters / (double)size;  
    percDGetters =  floor((percDGetters*100)+0.5)/100.0; 
    percFGetters = 100.0 * (double)numFGetters / (double)size;  
    percFGetters =  floor((percFGetters*100)+0.5)/100.0; 
    
    int studCountDig = 0;
    int studentCt = students.size();
    while(studentCt > 0)
    {
       studentCt  /= 10;
       studCountDig++;
    }
    stream << "As = " << setw(studCountDig) << numAGetters << " " << percAGetters << "%" << endl;
    stream << "Bs = " << setw(studCountDig) << numBGetters << " " << percBGetters << "%" <<  endl;
    stream << "Cs = " << setw(studCountDig) << numCGetters << " " << percCGetters << "%" <<  endl;
    stream << "Ds = " << setw(studCountDig) << numDGetters << " " << percDGetters << "%" <<  endl;
    stream << "Fs = " << setw(studCountDig) << numFGetters << " " << percFGetters << "%" <<  endl << endl;
    // compute the average GPA
    gpa = 4.0 * myMean / 100.0;
    stream << "GPA = " << gpa << endl << endl;

    int maxNumDigits = 0;
    int maxWeight = ceilings[ceilings.size()-1];
    while(maxWeight > 0)
    {
       maxWeight  /= 10;
       maxNumDigits++;
    }
    //stream << maxNumDigits << endl;

    stream << "ID    Unique TA       Scores";
    int scoresTxtSize = 6;
    for(int i = 0; i < (int)weights.size(); i++)
    {
        for(int temp = maxNumDigits+1; temp > 0; temp--)
        {
            if(scoresTxtSize == 0)
                stream << " ";
            else
                scoresTxtSize--;
        }
    }
    stream << " Total  Z     G" << endl;

    stream << "----- ------ -------- ";

    int counter = 0; 
    
    for(int i = 0; i < (int)weights.size(); i++)
    {
        for(int temp = maxNumDigits+1; temp > 0; temp--){
            stream << "-";
            counter++;
        }
    }
    while(counter < 6){
        stream << "-";
        counter++;
    }
    
    stream << " ------ ----- -" << endl;
    
    vector<int>* temp;
    
    for(int i=0;i<size;i++){
        
        
        
        stream << students[i].id << " " << setfill('0') << right << setw(5) << students[i].unique << "  " << setfill(' ') << left << setw(8) << students[i].taName << " ";
        

        temp = &students[i].scores;
        for(int j=0;j<numEvents;j++){
            stream << right << setfill(' ') << setw(maxNumDigits+1) << (*temp)[j];
        }
        
        if(numEvents == 1) stream << "   ";
        
        stream << " " << setw(5) << right << setprecision(4) << students[i].totalScore << "% " << setw(5) << right << students[i].zScore << " " << students[i].letterGrade << endl;
        
    }
    stream << endl;
    
}


// -------------------
// grades_gradeStudent
// -------------------

/**
* grades an individual student with the weighted total score and a letter grade.
* @param input a std::istream
*/

void grades_gradeStudent(Student& student){ // grades an individual student
    double total = 0.0;
    for(int i=0; i<numEvents; i++){
        total += ((double)(student.scores[i]) / (double)(ceilings[i]) * (double)(weights[i]) ); 
    }
    student.totalScore = floor((total*100)+0.5)/100.0; 

    if(total >= 89.5){
        student.letterGrade = 'A';
        numAGetters++;
    }
    else if(total >= 79.5){
        student.letterGrade = 'B';
        numBGetters++;
    }
    else if(total >= 69.5){
        student.letterGrade = 'C';
        numCGetters++;
    }
    else if(total >= 59.5){
        student.letterGrade = 'D';
        numDGetters++;
    }
    else{
        student.letterGrade = 'F';
        numFGetters++;
    }
}

// -----------
// grades_read
// -----------

/**
* Read the input file, parse the content, and construct Student objects accordingly.
* @param input a std::istream
* @param testing If it's true, do not print
*/
void grades_read (std::istream& input, bool testing) { // parse the input file and store the data publicly
    stringstream stream;
    string word;
    string line;
    getline(input, line);
    
    //eof might not always work, instead, this checks if the bad bit of input was set - will always work
    while(input){
    
        students.clear(); // new course
        
        numAGetters = 0;
        numBGetters = 0;
        numCGetters = 0;
        numDGetters = 0;
        numFGetters = 0;
    
        numEvents = atoi(line.c_str()); // numEvents set 
        
        ceilings.clear();
        weights.clear();
        getline(input, line);
        
        stream.clear();
        stream.str(line);
        
        int counter = 0;
        
        while(getline(stream, word, ' ') && counter < numEvents) {
            ceilings.push_back(atoi(word.c_str()));
            counter++; 
        }
        counter = 0;
        getline(input, line);
        stream.clear();
        stream.str(line);
        string myStr = stream.str();
        
        while(getline(stream, word, ' ') && counter < numEvents) {
            weights.push_back(atoi(word.c_str()));
            counter++; 
        }
        
        counter = 0;
        
        while(getline(input, line) && line != ""){//strcmp(line.c_str(), "")){
            stringstream stream(line);
            getline(stream, word, ' ');
            Student newStudent;
            newStudent.id = word;
            getline(stream, word, ' ');
            newStudent.unique = atoi(word.c_str());
            getline(stream, word, ' ');
            newStudent.taName = word;
            //newStudent.scores = make1DIntArray(numEvents);
            //int newStudent.scores[numEvents];
            while(getline(stream, word, ' ') && counter < numEvents){
                newStudent.scores.push_back(atoi(word.c_str()));
                counter++; 
            }
            counter = 0;
            grades_gradeStudent(newStudent);
            students.push_back(newStudent);
        }
        size = students.size(); 
        getline(input, line);
        
        // compute the Z-score, sort the students by grade
        
        grades_processStudents(students);
        sort(students.begin(), students.end());
        if(!testing) grades_print(cout);
    }
}



