/**
*
* @author Wonjun Lee
*
*/

// -----------------------------
// projects/collatz/Collatz.java
// Copyright (C) 2011
// Glenn P. Downing
// -----------------------------

import java.io.IOException;
import java.io.Writer;

import java.util.Scanner;

public final class Collatz {
    private static final int SIZE = 1000000;
    private static int[] cache_eval = new int[SIZE]; //this array stores the maximum cycle lengths of index numbers that have been computed.
    private static int[] cache_cycLen = new int[SIZE];  //this array stores the cycle lengths of index numbers that have been computed.
    
    // ----
    // read
    // ----

    /**
* reads two ints into a[0] and a[1]
* @param r a java.util.Scanner
* @param a an array of int
* @return true if that succeeds, false otherwise
*/
    public static boolean read (Scanner r, int[] a) {
        if (!r.hasNextInt())
            return false;
        a[0] = r.nextInt();
        a[1] = r.nextInt();
        assert a[0] > 0;
        assert a[1] > 0;
        return true;}

    // ----
    // eval
    // ----

    /**
* Given ints i and j, computes getCycLen(n) for i<=n<=j, and returns the maximum value 
* @param i the beginning of the range, inclusive
* @param j the end of the range, inclusive
* @return the max cycle length in the range [i, j]
*/
    public static int eval (int i, int j) {
        assert i > 0;
        assert j > 0;
        // <your code>
    
        int v = 1;
        assert i < SIZE;
        assert j < SIZE; // i and j must be between 1 and a million, inclusive.
        int temp = 0;
        if(i > j){ // swap i and j to make sure that i <= j
            temp = j;
            j = i;
            i = temp;
        }
        assert i <= j;
        
        temp = 0;
        for(int k = SIZE-1; k >= 0; k--){ //find the known cycle length of the largest index
            if(cache_eval[k] > 0){
                if(j>=k && i<=(k>>1)){
                     temp = k;
                     break;
                }
            }
        }
        if(temp > 0){
            int a = eval(i, temp>>1); //divide-and-conquer
            int b = cache_eval[temp]; //shorcut shown in Quiz #3 (if i is less than k/2, ignore everything below k/2)
            int c = eval(temp, j); //divide-and-conquer
            v = ((a > b) ? a : b);
            v = ((v > c) ? v : c);
        }
        else{
            if(i < (j>>1)){
                if(cache_eval[j] > 0){
                    return cache_eval[j];
                }
                i = j>>1; //optimization as on Quiz #3
            }
            for(int k = i; k <= j; k++){
                temp = getCycLen(k);
                if(temp > v){
                    v = temp; //v temporarily stores the maximum value
                }
            } 
        }
        
        assert v > 0;
        cache_eval[j] = v;
        return v;}
    
    // ---------
    // getCycLen
    // ---------
    
    /**
* recursively computes the Collatz cycle length for n
* @param n the initial value for the algorithm
* @return the cycle length for the n
*/
public static int getCycLen (int n){ 
    //assert(n > 0);
    if(n <= 1){ //base case. halt at one
        return 1; 
    }
    else if(n % 2 == 1){ //odd
        if(n < SIZE){
            if(cache_cycLen[n] > 0) return cache_cycLen[n]; //the cache already has the answer
            cache_cycLen[n] = 2 + getCycLen( n + (n>>1) + 1 ); // 3n+1. Increment the counter by 2, since two cycles are executed in one
            return cache_cycLen[n]; //update the cache.
        }
        else return 2 + getCycLen( n + (n>>1) + 1 ); 
    }
    else{ //even
        if(n < SIZE){
            if(cache_cycLen[n] > 0) return cache_cycLen[n]; //the cache already has the answer
            cache_cycLen[n] = 1 + getCycLen( n>>1 ); // n/2.
            return cache_cycLen[n];  //update the cache.
        }
        return 1 + getCycLen( n>>1 );
    }
}

    // -----
    // print
    // -----

    /**
* prints the values of i, j, and v
* @param w a java.io.Writer
* @param i the beginning of the range, inclusive
* @param j the end of the range, inclusive
* @param v the max cycle length
*/
    public static void print (Writer w, int i, int j, int v) throws IOException {
        assert i > 0;
        assert j > 0;
        assert v > 0;
        w.write(i + " " + j + " " + v + "\n");
        w.flush();}

    // -----
    // solve
    // -----

    /**
* @param r a java.util.Scanner
* @param w a java.io.Writer
*/
    public static void solve (Scanner r, Writer w) throws IOException {
        final int[] a = {0, 0};
        while (Collatz.read(r, a)) {
            final int v = Collatz.eval(a[0], a[1]);
            Collatz.print(w, a[0], a[1], v);}}}
