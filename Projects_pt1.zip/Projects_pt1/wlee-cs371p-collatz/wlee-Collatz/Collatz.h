// --------------------------
// projects/collatz/Collatz.h
// Copyright (C) 2011
// Glenn P. Downing
// --------------------------

// --------
// includes
// --------

#include <cassert> // assert
#include <iostream> // endl, istream, ostream

#define SIZE 1000000

int cache_eval[SIZE] = {0}; //this array stores the maximum cycle lengths of index numbers that have been computed.
int cache_cycLen[SIZE] = {0};  //this array stores the cycle lengths of index numbers that have been computed.

// ------------
// collatz_read
// ------------

/**
* reads two ints into i and j
* @param r a std::istream
* @param i an int by reference
* @param j an int by reference
* @return true if that succeeds, false otherwise
*/
bool collatz_read (std::istream& r, int& i, int& j) {
    r >> i;
    if (!r)
        return false;
    r >> j;
    assert(i > 0);
    assert(j > 0);
    return true;}

// -----------------
// collatz_getCycLen
// -----------------
    
    /**
* recursively computes the Collatz cycle length for n
* @param n the initial value for the algorithm
* @return the cycle length for the n
*/
int collatz_getCycLen (int n){ 
    //assert(n > 0);
    if(n <= 1){ //base case. halt at one
        return 1; 
    }
    else if(n % 2 == 1){ //odd
        if(n < SIZE){
            if(cache_cycLen[n] > 0) return cache_cycLen[n]; //the cache already has the answer
            cache_cycLen[n] = 2 + collatz_getCycLen( n + (n>>1) + 1 ); // 3n+1. Increment the counter by 2, since two cycles are executed in one
            return cache_cycLen[n]; //update the cache.
        }
        else return 2 + collatz_getCycLen( n + (n>>1) + 1 ); 
    }
    else{ //even
        if(n < SIZE){
            if(cache_cycLen[n] > 0) return cache_cycLen[n]; //the cache already has the answer
            cache_cycLen[n] = 1 + collatz_getCycLen( n>>1 ); // n/2.
            return cache_cycLen[n];  //update the cache.
        }
        return 1 + collatz_getCycLen( n>>1 );
    }
}

// ------------
// collatz_eval
// ------------

/**
* Given ints i and j, computes getCycLen(n) for i<=n<=j, and returns the maximum value 
* @param i the beginning of the range, inclusive
* @param j the end of the range, inclusive
* @return the max cycle length in the range [i, j]
*/
int collatz_eval (int i, int j) {
    assert(i > 0);
    assert(j > 0);
    // <your code>
    
        int v = 1;
        assert(i < SIZE);
        assert(j < SIZE); // i and j must be between 1 and a million, inclusive.
        int temp = 0;
        if(i > j){ // swap i and j to make sure that i <= j
            temp = j;
            j = i;
            i = temp;
        }
        assert(i <= j);
        
        temp = 0;
        for(int k = SIZE-1; k >= 0; k--){ //find the known cycle length of the largest index
            if(cache_eval[k] > 0){
                if(j>=k && i<=(k>>1)){
                     temp = k;
                     break;
                }
            }
        }
        if(temp > 0){
            int a = collatz_eval(i, temp>>1); //divide-and-conquer
            int b = cache_eval[temp]; //shorcut shown in Quiz #3 (if i is less than k/2, ignore everything below k/2)
            int c = collatz_eval(temp, j); //divide-and-conquer
            v = ((a > b) ? a : b);
            v = ((v > c) ? v : c);
        }
        else{
            if(i < (j>>1)){
                if(cache_eval[j] > 0){
                    return cache_eval[j];
                }
                i = j>>1; //optimization as on Quiz #3
            }
            for(int k = i; k <= j; k++){
                temp = collatz_getCycLen(k);
                if(temp > v){
                    v = temp; //v temporarily stores the maximum value
                }
            } 
        }
        
        assert(v > 0);
        cache_eval[j] = v;
        return v;}

// -------------
// collatz_print
// -------------

/**
* prints the values of i, j, and v
* @param w a std::ostream
* @param i the beginning of the range, inclusive
* @param j the end of the range, inclusive
* @param v the max cycle length
*/
void collatz_print (std::ostream& w, int i, int j, int v) {
    assert(i > 0);
    assert(j > 0);
    assert(v > 0);
    w << i << " " << j << " " << v << std::endl;}

// -------------
// collatz_solve
// -------------

/**
* read, eval, print loop
* @param r a std::istream
* @param w a std::ostream
*/
void collatz_solve (std::istream& r, std::ostream& w) {
    int i;
    int j;
    while (collatz_read(r, i, j)) {
        const int v = collatz_eval(i, j);
        collatz_print(w, i, j, v);}}
