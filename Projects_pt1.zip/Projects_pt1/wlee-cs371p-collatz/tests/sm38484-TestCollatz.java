// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------
// Sogol Moshtaghi
// ---------------------------------

/*
 To test the program:
 % locate junit4-4.8
 /usr/share/java/junit4-4.8.1.jar
 % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
 set CLASSPATH=.;C:\junit4.10\junit-4.10.jar (WINDOWS)
 % javac -Xlint TestCollatz.java
 % java  -ea    TestCollatz > TestCollatz.java.out
 */

// -------
// imports
// -------
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
        // ----
        // read
        // ----

        public void testRead() {
                final Scanner r = new Scanner("1 10\n");
                final int a[] = { 0, 0 };
                final boolean b = Collatz.read(r, a);
                Assert.assertTrue(b == true);
                Assert.assertTrue(a[0] == 1);
                Assert.assertTrue(a[1] == 10);
        }
        
        public void testRead_lowerBound() {
                final Scanner r = new Scanner("1 1\n");
                final int a[] = { 0, 0 };
                final boolean b = Collatz.read(r, a);
                Assert.assertTrue(b == true);
                Assert.assertTrue(a[0] == 1);
                Assert.assertTrue(a[1] == 1);
        }
        
        public void testRead_mid1() {
                final Scanner r = new Scanner("499999 500000\n");
                final int a[] = { 0, 0 };
                final boolean b = Collatz.read(r, a);
                Assert.assertTrue(b == true);
                Assert.assertTrue(a[0] == 499999);
                Assert.assertTrue(a[1] == 500000);
        }

	public void testRead_range() {
                final Scanner r = new Scanner("1 999999\n");
                final int a[] = { 0, 0 };
                final boolean b = Collatz.read(r, a);
                Assert.assertTrue(b == true);
                Assert.assertTrue(a[0] == 1);
                Assert.assertTrue(a[1] == 999999);
        }
        
        public void testRead_mid2() {
                final Scanner r = new Scanner("500000 499999\n");
                final int a[] = { 0, 0 };
                final boolean b = Collatz.read(r, a);
                Assert.assertTrue(b == true);
                Assert.assertTrue(a[0] == 500000);
                Assert.assertTrue(a[1] == 499999);
        }
        
        public void testRead_upperBound() {
                final Scanner r = new Scanner("999999 999999\n");
                final int a[] = { 0, 0 };
                final boolean b = Collatz.read(r, a);
                Assert.assertTrue(b == true);
                Assert.assertTrue(a[0] == 999999);
                Assert.assertTrue(a[1] == 999999);
        }
        
        public void testRead_noInput() {
                final Scanner r = new Scanner("");
                final int a[] = { 0, 0 };
                final boolean b = Collatz.read(r, a);
                Assert.assertTrue(b == false);
                Assert.assertTrue(a[0] == 0);
                Assert.assertTrue(a[1] == 0);
        }
        
        public void testRead_wrong() {
                final Scanner r = new Scanner("1 1\n");
                final int a[] = { 0, 0 };
                final boolean b = Collatz.read(r, a);
                Assert.assertTrue(b == true);
                Assert.assertFalse(a[0] == 2);
                Assert.assertFalse(a[1] == 2);
        }

        // ----
        // eval
        // ----

        public void testEval1() {
                final int v = Collatz.eval(1, 10);
                Assert.assertTrue(v == 20);
        }

        public void testEval2() {
                final int v = Collatz.eval(100, 200);
                Assert.assertTrue(v == 125);
        }

        public void testEval3() {
                final int v = Collatz.eval(201, 210);
                Assert.assertTrue(v == 89);
        }

        public void testEval4() {
                final int v = Collatz.eval(900, 1000);
                Assert.assertTrue(v == 174);
        }

         public void testEvalSwap() {
                final int v = Collatz.eval(9, 2);
                Assert.assertTrue(v == 20);
        }
        
         public void testEvalRange() {
                final int v = Collatz.eval(1, 999999);
                Assert.assertTrue(v == 525);
        }

        public void testEvalEdgelow() {
                final int v = Collatz.eval(1, 1);
                Assert.assertTrue(v == 1);
        }

	public void testEvalbullshit() {
                final int v = Collatz.eval(232545, 681701);
                Assert.assertTrue(v == 509); 
        }
        
        public void testEvalMid() {
                final int v = Collatz.eval(499999, 500000);
                Assert.assertTrue(v == 258);
        }
        
        public void testEvalGreat() {
                final int v = Collatz.eval(500000, 499999);
                Assert.assertTrue(v == 258);
        }
        
        public void testEvalEdge() {
                final int v = Collatz.eval(999999, 999999);
                Assert.assertTrue(v == 259);
        }
        
    

        // -----
        // print
        // -----

        public void testPrint() throws IOException {
                final Writer w = new StringWriter();
                Collatz.print(w, 1, 10, 20);
                Assert.assertTrue(w.toString().equals("1 10 20\n"));
        }
        
        public void testPrint_Edgelow() throws IOException {
                final Writer w = new StringWriter();
                Collatz.print(w, 1, 1, 1);
                Assert.assertTrue(w.toString().equals("1 1 1\n"));
        }
        
        public void testPrint_mid1() throws IOException {
                final Writer w = new StringWriter();
                Collatz.print(w, 499999, 500000, 258);
                Assert.assertTrue(w.toString().equals("499999 500000 258\n"));
        }
        
        public void testPrint_great() throws IOException {
                final Writer w = new StringWriter();
                Collatz.print(w, 500000, 499999, 258);
                Assert.assertTrue(w.toString().equals("500000 499999 258\n"));
        }

         public void testPrint_range() throws IOException {
                final Writer w = new StringWriter();
                Collatz.print(w, 1, 999999, 525);
                Assert.assertTrue(w.toString().equals("1 999999 525\n"));
        }
        
        public void testPrint_edge() throws IOException {
                final Writer w = new StringWriter();
                Collatz.print(w, 999999, 999999, 259);
                Assert.assertTrue(w.toString().equals("999999 999999 259\n"));
        }
        
         
        public void testPrint_swap() throws IOException {
                final Writer w = new StringWriter();
                Collatz.print(w, 9, 2, 20);
                Assert.assertTrue(w.toString().equals("9 2 20\n"));
        }

        // -----
        // solve
        // -----

        public void testSolve() throws IOException {
                final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
                final Writer w = new StringWriter();
                Collatz.solve(r, w);
                Assert.assertTrue(w.toString().equals(
                                "1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));
        }
        
        public void testSolve1() throws IOException {
                final Scanner r = new Scanner("1 1\n499999 500000\n500000 499999\n999999 999999\n");
                final Writer w = new StringWriter();
                Collatz.solve(r, w);
                Assert.assertTrue(w.toString().equals(
                                "1 1 1\n499999 500000 258\n500000 499999 258\n999999 999999 259\n"));
        }
        
        public void testSolve2() throws IOException {
                final Scanner r = new Scanner("2 9\n2 2\n9 2\n 1 999999\n");
                final Writer w = new StringWriter();
                Collatz.solve(r, w);
                Assert.assertTrue(w.toString().equals(
                                "2 9 20\n2 2 2\n9 2 20\n1 999999 525\n"));
        }
        
    
        

        
 

        // ----
        // main
        // ----

        public static void main(String[] args) {
                System.out.println("TestCollatz.java");
                TestRunner.run(new TestSuite(TestCollatz.class));
                System.out.println("Done.");
        }
}

 


