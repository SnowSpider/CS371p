// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase
{
  // ----
  // read
  // ----

  public void testRead()
  {
    final Scanner r = new Scanner("1 10\n");
    final int a[] = {0, 0};
    final boolean b = Collatz.read(r, a);
    Assert.assertTrue(b == true);
    Assert.assertTrue(a[0] == 1);
    Assert.assertTrue(a[1] == 10);
  }

  public void testRead_same_numbers() 
  {
    final Scanner r = new Scanner("10 10\n");
    final int a[] = {0, 0};
    final boolean b = Collatz.read(r, a);
    Assert.assertTrue(b == true);
    Assert.assertTrue(a[0] == 10);
    Assert.assertTrue(a[1] == 10);
  }

  public void testRead_reverse_order() 
  {
    final Scanner r = new Scanner("1000 1\n");
    final int a[] = {0, 0};
    final boolean b = Collatz.read(r, a);
    Assert.assertTrue(b == true);
    Assert.assertTrue(a[0] == 1000);
    Assert.assertTrue(a[1] == 1);
  }

  public void testRead_too_many_numbers() 
  {
    final Scanner r = new Scanner("1 2 3 4\n");
    final int a[] = {0, 0};
    final boolean b = Collatz.read(r, a);
    Assert.assertTrue(b == true);
    Assert.assertTrue(a[0] == 1);
    Assert.assertTrue(a[1] == 2);
  }

  // ----
  // eval
  // ----

  public void testEval1()
  {
    final int v = Collatz.eval(1, 10);
    Assert.assertTrue(v == 20);
  }

  public void testEval2() 
  {
    final int v = Collatz.eval(100, 200);
    Assert.assertTrue(v == 125);
  }

  public void testEval3() 
  {
    final int v = Collatz.eval(201, 210);
    Assert.assertTrue(v == 89);
  }

  public void testEval4() 
  {
    final int v = Collatz.eval(900, 1000);
    Assert.assertTrue(v == 174);
  }

  public void testEval_overflow() 
  {
    final int v = Collatz.eval(828005, 827945);
    Assert.assertTrue(v == 274);
  }

  public void testEval_overflow2()
  {
    final int v = Collatz.eval(482659, 474574);
    Assert.assertTrue(v == 413);
  }

  public void testEval_overflow3()
  {
    final int v = Collatz.eval(232545, 681701);
    Assert.assertTrue(v == 509);
  }

  public void testEval_overflow4()
  {
    final int v = Collatz.eval(773104, 675975);
    Assert.assertTrue(v == 504);
  }

  // -----
  // print
  // -----

  public void testPrint()
  {
    final Writer w = new StringWriter();
    try {
      Collatz.print(w, 1, 10, 20);
    } catch(Exception e) {
      Assert.fail("Unexpected exception");
    }
    Assert.assertTrue(w.toString().equals("1 10 20\n"));
  }

  public void testPrint_small()
  {
    final Writer w = new StringWriter();
    try {
      Collatz.print(w, 1, 1, 1);
    } catch(Exception e) {
      Assert.fail("Unexpected exception");
    }
    Assert.assertTrue(w.toString().equals("1 1 1\n"));
  }

  public void testPrint_big()
  {
    final Writer w = new StringWriter();
    try {
      Collatz.print(w, Integer.MAX_VALUE, Integer.MAX_VALUE, 
          Integer.MAX_VALUE);
    } catch(Exception e) {
      Assert.fail("Unexpected exception");
    }
    Assert.assertTrue(w.toString().equals(Integer.MAX_VALUE + " " 
          + Integer.MAX_VALUE + " " + Integer.MAX_VALUE + "\n"));
  }

  public void testPrint_middle()
  {
    final Writer w = new StringWriter();
    try {
      Collatz.print(w, Integer.MAX_VALUE / 2, Integer.MAX_VALUE / 2, 
          Integer.MAX_VALUE / 2);
    } catch(Exception e) {
      Assert.fail("Unexpected exception");
    }
    Assert.assertTrue(w.toString().equals(Integer.MAX_VALUE / 2 + " " 
          + Integer.MAX_VALUE / 2 + " " + Integer.MAX_VALUE / 2 + "\n"));
  }

  // -----
  // solve
  // -----

  public void testSolve()
  {
    final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
    final Writer w = new StringWriter();
    try {
      Collatz.solve(r, w);
    } catch(Exception e) {
      Assert.fail("Unexpected exception");
    }
    Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n"
          + "201 210 89\n900 1000 174\n"));
  }

  public void testSolve_overflow()
  {
    final Scanner r = new Scanner("828005 827945\n482659 474574\n");
    final Writer w = new StringWriter();
    try {
      Collatz.solve(r, w);
    } catch(Exception e) {
      Assert.fail("Unexpected exception");
    }
    Assert.assertTrue(w.toString().equals("828005 827945 274\n"
          + "482659 474574 413\n"));
  }

  public void testSolve_overflow2()
  {
    final Scanner r = new Scanner("232545 681701\n773104 675975\n");
    final Writer w = new StringWriter();
    try {
      Collatz.solve(r, w);
    } catch(Exception e) {
      Assert.fail("Unexpected exception");
    }
    Assert.assertTrue(w.toString().equals("232545 681701 509\n"
          + "773104 675975 504\n"));
  }

  public void testSolve_small()
  {
    final Scanner r = new Scanner("10 1\n2 2\n4 1\n");
    final Writer w = new StringWriter();
    try {
      Collatz.solve(r, w);
    } catch(Exception e) {
      Assert.fail("Unexpected exception");
    }
    Assert.assertTrue(w.toString().equals("10 1 20\n2 2 2\n4 1 8\n"));
  }

  // ----
  // main
  // ----

  public static void main(String[] args) 
  {
    System.out.println("TestCollatz.java");
    TestRunner.run(new TestSuite(TestCollatz.class));
    System.out.println("Done.");
  }
}
