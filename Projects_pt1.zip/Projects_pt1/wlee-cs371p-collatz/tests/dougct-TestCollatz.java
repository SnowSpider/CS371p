// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {

  long[] cache = new long[100000]; 
    
  // ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final long     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);
    }

  
  public void testRead_1 () {
    final Scanner r   = new Scanner("1 999999\n");
    final long     a[] = {0, 0};
    final boolean b   = Collatz.read(r, a);
    Assert.assertTrue(b    == true);
    Assert.assertTrue(a[0] ==    1);
    Assert.assertTrue(a[1] ==    999999);
  }

  
  public void testRead_2 () {
    final Scanner r   = new Scanner("1 1\n");
    final long     a[] = {0, 0};
    final boolean b   = Collatz.read(r, a);
    Assert.assertTrue(b    == true);
    Assert.assertTrue(a[0] ==    1);
    Assert.assertTrue(a[1] ==    1);
  }

  
  public void testRead_3 () {
    final Scanner r   = new Scanner("234 134\n");
    final long     a[] = {0, 0};
    final boolean b   = Collatz.read(r, a);
    Assert.assertTrue(b    == true);
    Assert.assertTrue(a[0] ==    234);
    Assert.assertTrue(a[1] ==    134);
  }

  
  // ----
	// cycle_length
	// ----
  
	public void test_cycle_length_1() {
		final long v = Collatz.cycle_length(1, cache);
		Assert.assertTrue(v == 1);
	}

  
  public void test_cycle_length_2() {
		final long v = Collatz.cycle_length(2, cache);
		Assert.assertTrue(v == 2);
	}

  
  public void test_cycle_length_3() {
		final long v = Collatz.cycle_length(3, cache);
		Assert.assertTrue(v == 8);
	}

  
  public void test_cycle_length_4() {
		final long v = Collatz.cycle_length(22, cache);
		Assert.assertTrue(v == 16);
	}

  
  public void test_cycle_length_5() {
		final long v = Collatz.cycle_length(999999, cache);
		Assert.assertTrue(v == 259);
	}

  
  public void test_cycle_length_6() {
		final long v = Collatz.cycle_length(600, cache);
		Assert.assertTrue(v == 18);
	}

  
  public void test_cycle_length_7() {
		final long v = Collatz.cycle_length(10000, cache);
		Assert.assertTrue(v == 30);
	}

  
  public void test_cycle_length_8() {
		final long v = Collatz.cycle_length(3456, cache);
		Assert.assertTrue(v == 119);
	}

  
  public void test_cycle_length_9() {
		final long v = Collatz.cycle_length(250000, cache);
		Assert.assertTrue(v == 151);
	}

  
  public void test_cycle_length_10() {
		final long v = Collatz.cycle_length(350000, cache);
		Assert.assertTrue(v == 167);
	}
   
   
    // ----
    // eval
    // ----

    public void testEval1 () {
        final long v = Collatz.eval(1, 10, cache);
    	Assert.assertTrue(v == 20);
    }

    public void testEval2 () {
        final long v = Collatz.eval(100, 200, cache);
    	Assert.assertTrue(v == 125);
    }

    public void testEval3 () {
        final long v = Collatz.eval(201, 210, cache);
    	Assert.assertTrue(v == 89);
    }

    public void testEval4 () {
        final long v = Collatz.eval(900, 1000, cache);
    	Assert.assertTrue(v == 174);
    }

    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));
    }

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
      Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));
    }

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");
    }
}
