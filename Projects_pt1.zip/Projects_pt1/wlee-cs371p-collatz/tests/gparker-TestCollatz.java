// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import org.omg.CosNaming.NamingContextPackage.NotFound;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead1 () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
    	
    public void testRead2 () {
        final Scanner r   = new Scanner("1 1\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   1);}
    	
    public void testRead3 () {
        final Scanner r   = new Scanner("999999 999999\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==   999999);
    	Assert.assertTrue(a[1] ==   999999);}
    	
    public void testRead4 () {
        final Scanner r   = new Scanner("1 999999\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==   1);
    	Assert.assertTrue(a[1] ==   999999);}

    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}
    	
    	
    // --------
    // cycleLen
    // --------
    
    public void testCycleLen1() {
        final int x = Collatz.cycleLen(5);
        Assert.assertTrue(x == 6);
    }
    
    public void testCycleLen2() {
        final int x = Collatz.cycleLen(1);
        Assert.assertTrue(x == 1);
    }
    
    public void testCycleLen3() {
        final int x = Collatz.cycleLen(10);
        Assert.assertTrue(x == 7);
    }
    
    public void testCycleLen4() {
        final int x = Collatz.cycleLen(459759);
        Assert.assertTrue(x == 214);
    }


    // -----
    // print
    // -----

    public void testPrint1 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
    	
    public void testPrint2 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 1, 1);
    	Assert.assertTrue(w.toString().equals("1 1 1\n"));}
    	
    public void testPrint3 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 50, 500, 5000);
    	Assert.assertTrue(w.toString().equals("50 500 5000\n"));}

    // -----
    // solve
    // -----

    public void testSolve1 () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
    	
    public void testSolve2 () throws IOException {
        final Scanner r = new Scanner("917517 140624\n815404 971300\n395198 1969\n530418 1032\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("917517 140624 525\n815404 971300 525\n395198 1969 443\n530418 1032 470\n"));}
    
    public void testSolve3 () throws IOException {
        final Scanner r = new Scanner("483869 940924\n70974 904741\n642215 500438\n38671 589128\n984681 594237\n786278 68856\n591926 94280\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("483869 940924 525\n70974 904741 525\n642215 500438 509\n38671 589128 470\n984681 594237 525\n786278 68856 509\n591926 94280 470\n"));}
    
    public void testSolve4 () throws IOException {
        final Scanner r = new Scanner("819350 142041\n952249 220800\n298785 716907\n608817 215228\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("819350 142041 509\n952249 220800 525\n298785 716907 509\n608817 215228 470\n"));}
    
    
    // -----
    // cache
    // -----
    
    public void testCache1 () {
    	Cache cache = new Cache();
    	cache.write(1, 1);
    	cache.write(Cache.size(), 259);
    	
    	try {
			Assert.assertEquals(1, cache.read(1));
			Assert.assertEquals(259, cache.read(Cache.size()));
		} catch (NotFound e) {
			fail();
		}
    }
    
    public void testCache2 () {
    	Cache cache = new Cache();
    	
    	cache.write(4, 2);
    	cache.write(6, 1);
    	
    	try {
			cache.read(5);
		} catch (NotFound e) {
			return;
		}
    	fail();
    }
    
    public void testCache3 () {
    	Cache cache = new Cache();
    	cache.write(65432, 46843);
    	cache.write(123, 897864);
    	
    	try {
			Assert.assertEquals(46843, cache.read(65432));
			Assert.assertEquals(897864, cache.read(123));
		} catch (NotFound e) {
			fail();
		}
    }

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");
    }
}
