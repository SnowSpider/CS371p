// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
    
    public void testRead2 () {
        final Scanner r   = new Scanner("\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == false);}
    
    public void testRead3 () {
        final Scanner r   = new Scanner("");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == false);}
    
    public void testRead4 () {
        final Scanner r   = new Scanner("22   48 \n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    22);
    	Assert.assertTrue(a[1] ==   48);}

    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
       final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(210, 201);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}
    
    public void testEval5 () {
        final int v = Collatz.eval(159487, 159487);
        Assert.assertTrue(v == 184);}
    
    public void testEval6 () {
        final int v = Collatz.eval(3,3);
        Assert.assertTrue(v == 8);}
    
    public void testEval7 () {
        final int v = Collatz.eval(232545, 681701);
        Assert.assertTrue(v == 509);}
    
    public void testEval8 () {
        final int v = Collatz.eval(773104, 675975);
        Assert.assertTrue(v == 504);}
    
    // ----
    // isEven
    // ----
    
    public void testIsEven1 () {
    	final boolean bool = Collatz.isEven(0);
    	Assert.assertTrue(bool == true);
    }
    
    public void testIsEven2 () {
    	final boolean bool = Collatz.isEven(139);
    	Assert.assertTrue(bool == false);
    }
    
    public void testIsEven3 () {
    	final boolean bool = Collatz.isEven(1288888);
    	Assert.assertTrue(bool == true);
    }

    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
    	
    public void testPrint2 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 31, 45, 1310);
    	Assert.assertTrue(w.toString().equals("31 45 1310\n"));}
    
    public void testPrint3 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 239, 1319, 1345999);
    	Assert.assertTrue(w.toString().equals("239 1319 1345999\n"));}
    
    public void testPrint4 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 13140, 0, 913);
    	Assert.assertTrue(w.toString().equals("13140 0 913\n"));}

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
    
    public void testSolve2 () throws IOException {
        final Scanner r = new Scanner("841394 131151\n379313 722173\n365503 253523\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("841394 131151 525\n379313 722173 509\n365503 253523 441\n"));}
    
    public void testSolve3 () throws IOException {
        final Scanner r = new Scanner("222821 289377\n530625 884150\n464313 706139\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("222821 289377 443\n530625 884150 525\n464313 706139 509\n"));}
    
    public void testSolve4 () throws IOException {
        final Scanner r = new Scanner("874600 948185\n166039 945063\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("874600 948185 507\n166039 945063 525\n"));}
    
    public void testSolve5 () throws IOException {
        final Scanner r = new Scanner("2482 523139\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("2482 523139 470\n"));}

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
