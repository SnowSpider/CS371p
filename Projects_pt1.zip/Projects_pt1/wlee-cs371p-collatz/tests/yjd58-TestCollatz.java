// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);
    }

    public void testRead2 () {
        final Scanner r   = new Scanner("1000000 2\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1000000);
    	Assert.assertTrue(a[1] ==   2);
    }

    public void testRead3 () {
        final Scanner r   = new Scanner("555 55555\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    555);
    	Assert.assertTrue(a[1] ==   55555);
    }

    public void testRead4 () {
        final Scanner r   = new Scanner("343 343\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    343);
    	Assert.assertTrue(a[1] ==   343);
    }



    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);
    }

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);
    }

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);
    }

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);
    }
    
    // -------------
    // my eval tests
    // -------------
    public void testEval5 () {
        final int v = Collatz.eval(1, 4);
    	Assert.assertTrue(v == 8);
    }
    
    public void testEval6 () {
        final int v = Collatz.eval(400001, 500000);
    	Assert.assertTrue(v == 449);
    }
    
    public void testEval7 () {
        final int v = Collatz.eval(800001, 900000);
        Assert.assertTrue(v == 525);
    }

    public void testEvalOne1 () {
    	final int v = Collatz.evalOne(1);
    	Assert.assertTrue(v == 1);
    }
    
    public void testEvalOne2 () {
    	final int v = Collatz.evalOne(5);
    	Assert.assertTrue(v == 6);
    }
    
    public void testEvalOne3 () {
    	final int v = Collatz.evalOne(27);
    	Assert.assertTrue(v == 112);
    }
    
    public void testEvalOne4 () {
    	final int v = Collatz.evalOne(24576);
    	Assert.assertTrue(v == 21);
    }
   
    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));
    }

    public void testPrint2 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 234, 123, 67);
        Assert.assertTrue(w.toString().equals("234 123 67\n"));
    }

    public void testPrint3 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1000000, 374, 1);
        Assert.assertTrue(w.toString().equals("1000000 374 1\n"));
    }

    public void testPrint4 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 5, 5, 6);
        Assert.assertTrue(w.toString().equals("5 5 6\n"));
    }

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));
    }
    
    public void testSolve2 () throws IOException {
    	final Scanner r = new Scanner("10 1\n200 100\n210 201\n1000 900\n");
    	final Writer w = new StringWriter();
    	Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("10 1 20\n200 100 125\n210 201 89\n1000 900 174\n"));
    }

    public void testSolve3 () throws IOException {
    	final Scanner r = new Scanner("481354 485994\n934511 808512\n257972 114931\n935653 271837\n941784 299817\n665839 754049\n36170 412962\n850817 184452\n975033 975933\n691108 152452"); 
    	final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("481354 485994 382\n934511 808512 525\n257972 114931 443\n935653 271837 525\n941784 299817 525\n665839 754049 504\n36170 412962 449\n850817 184452 525\n975033 975933 339\n691108 152452 509\n"));
    }
    
    
    public void testSolve4 () throws IOException {
        final Scanner r = new Scanner("10000 100000\n100001 200000\n200001 300000\n900001 1000000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
        Assert.assertTrue(w.toString().equals("10000 100000 351\n100001 200000 383\n200001 300000 443\n900001 1000000 507\n"));
    }
    
    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
