// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
    	
    public void testReadWhitespace () {
        final Scanner r   = new Scanner("1      10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
    	
    public void testReadFail () {
        final Scanner r   = new Scanner("1 10\n\n\n21");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);
    	try {
    		final boolean c   = Collatz.read(r, a);
    		Assert.assertTrue(false);
    	} catch(Exception e) {
    		
    	}}
    	
    public void testReadMultiline () {
        final Scanner r   = new Scanner("1 10\n2 20\n");
        final int     a[] = {0, 0};
        boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);
    	
    	b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    2);
    	Assert.assertTrue(a[1] ==   20);}

    // ----
    // eval
    // ----

    public void testEvalSphere1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEvalSphere2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEvalSphere3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEvalSphere4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}
    	
    public void testEvalReversed () {
        final int v = Collatz.eval(10, 1);
    	Assert.assertTrue(v == 20);}
    	
    public void testEvalSame () {
        final int v = Collatz.eval(3, 3);
    	Assert.assertTrue(v == 8);}
    	
    public void testEvalOverflow () {
    	final int v = Collatz.eval(266138, 966707);
    	Assert.assertTrue(v == 525);}
    	
    // -----
    // eval
    // -----
    
    public void testCalcEval1() {
    	final long v = Collatz.eval(1);
    	Assert.assertTrue(v == 1);
    }
    
    public void testCalcEval5() {
    	final long v = Collatz.eval(5);
    	Assert.assertTrue(v == 6);
    }
    
    public void testCalcEval4() {
    	final long v = Collatz.eval(4);
    	Assert.assertTrue(v == 3);
    }
    
    // -----
    // store/get
    // ------
    
    public void testStore() {
    	Collatz.store(3, 7);
    	Assert.assertTrue(Collatz.get(3) == 7);
    	Collatz.store(3, 0);
    	Assert.assertTrue(Collatz.get(3) == 0);
    }
    
    public void testNotStored() {
    	Assert.assertTrue(Collatz.get(3) == 0);
    	Assert.assertTrue(Collatz.get(1293) == 0);
    	Assert.assertTrue(Collatz.get(123343) == 0);
    }
    
    public void testLargeNumbers() {
    	Collatz.store(3123523, 7); //Shouldn't store over a million
    	Assert.assertTrue(Collatz.get(3123523) == 0);
    }

    // -----
    // print
    // -----

    public void testPrintSphere1 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
    
    public void testPrintSphere2 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 100, 200, 125);
    	Assert.assertTrue(w.toString().equals("100 200 125\n"));}
    
    public void testPrintSphere3 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 201, 210, 89);
    	Assert.assertTrue(w.toString().equals("201 210 89\n"));}
    	
    public void testPrintSphere4 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 900, 1000, 174);
    	Assert.assertTrue(w.toString().equals("900 1000 174\n"));}
    
    public void testPrintMultiline () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 900, 1000, 174);
        Collatz.print(w, 201, 210, 89);
    	Assert.assertTrue(w.toString().equals("900 1000 174\n201 210 89\n"));}

    // -----
    // solve
    // -----

    public void testSolveSphere () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
    
    public void testSolveSingle () throws IOException {
        final Scanner r = new Scanner("1 10\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
    	
    public void testSolveWhitespace () throws IOException {
        final Scanner r = new Scanner("1   10   \n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
    	
    public void testSolveNewlines () throws IOException {
        final Scanner r = new Scanner("1 10\n\n\n100 200\n201 210\n\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
