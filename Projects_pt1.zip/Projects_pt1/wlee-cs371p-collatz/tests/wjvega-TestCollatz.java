// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Random;
import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
    
    public void testRead_EOF () {
        final Scanner r   = new Scanner("");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == false);}
    
    public void testRead_jIsGreater () {
        final Scanner r   = new Scanner("1000 10000\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1000);
    	Assert.assertTrue(a[1] ==   10000);}
    
    public void testRead_iIsGreater () {
        final Scanner r   = new Scanner("10000 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    10000);
    	Assert.assertTrue(a[1] ==   10);}
    
    public void testRead_ijEqual() {
        final Scanner r   = new Scanner("178 178\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    178);
    	Assert.assertTrue(a[1] ==   178);}
    
    public void testRead_lowerBound() {
        final Scanner r   = new Scanner("1 1\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   1);}
    
    public void testRead_upperBound(){
        final Scanner r   = new Scanner("999999 999999\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    999999);
    	Assert.assertTrue(a[1] ==   999999);}
    
    public void testRead_invalidInput_Text(){
        final Scanner r   = new Scanner("howdy oop\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == false);}
    
    public void testRead_invalidInput_Int(){
        final Scanner r   = new Scanner("1134\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == false);}
    
    public void testRead_invalidInput_Smilelyface(){
        final Scanner r   = new Scanner(":)\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == false);}


    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}
    
    public void testEval_lowerBound() {
        final int v = Collatz.eval(1, 1);
        Assert.assertTrue(v == 1);}
    
    public void testEval_upperBound() {
        final int v = Collatz.eval(999999, 999999);
        Assert.assertTrue(v == 259);}

    public void testEval_jIsGreaterThani() {
        final int v = Collatz.eval(200, 100);
        Assert.assertTrue(v == 125);}
    
    public void testEval_outerLoop_upperRange() {
        final int v = Collatz.eval(2, 3);
        Assert.assertTrue(v == 8);}
    
    public void testEval_outerLoop_lowerRange() {
        final int v = Collatz.eval(3, 4);
        Assert.assertTrue(v == 8);}
    
    public void testEval_overflow() {
        final int v = Collatz.eval(288615, 288615);
        Assert.assertTrue(v == 389);}
    
    public void testEval_overflow2() {
        final int v = Collatz.eval(294217, 267095);
        Assert.assertTrue(v == 407);}
    
    public void testEval_overflow3() {
        final int v = Collatz.eval(502441, 502441);
        Assert.assertTrue(v == 333);}
    
    public void testEval_overflow4() {
        final int v = Collatz.eval(232545, 681701);
        Assert.assertTrue(v == 509);}
    
    public void testEval_overflow5() {
        final int v = Collatz.eval(773104, 675975);
        Assert.assertTrue(v == 504);}

    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
    
    public void testPrint_lower () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 1, 1);
    	Assert.assertTrue(w.toString().equals("1 1 1\n"));}
    
    public void testPrint_upper () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 999999, 999999, 259);
    	Assert.assertTrue(w.toString().equals("999999 999999 259\n"));}
    
    public void testPrint_random () throws IOException {
    	Random r = new Random();
        final Writer w = new StringWriter();
        int i = r.nextInt(1000000) + 1;
        int j = r.nextInt(1000000) + 1;
        int k = r.nextInt(1000000) + 1;
        Collatz.print(w, i, j, k);
    	Assert.assertTrue(w.toString().equals(i + " " + j + " " + k + "\n"));}

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
    
    public void testSolve2 () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
    
    public void testSolve3 () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
    
    public void testSolve4 () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
    
    //i == j
    public void testSolve5 () throws IOException {
        final Scanner r = new Scanner("22 22\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("22 22 16\n"));}
    
    //i == j, cache hit
    public void testSolve6 () throws IOException {
        final Scanner r = new Scanner("11 11\n 11 11\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("11 11 15\n11 11 15\n"));}

    public void testSolve7 () throws IOException {
        final Scanner r = new Scanner("999999 999990\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("999999 999990 259\n"));}
	
	public void testSolve_EOF() throws IOException {
	        final Scanner r = new Scanner("");
	        final Writer w = new StringWriter();
	        Collatz.solve(r, w);
	        Assert.assertTrue(w.toString().equals(""));}
	
	public void testSolve_invalidInput() throws IOException {
        final Scanner r = new Scanner("11 11\n 11 :P\n");
        final Writer w = new StringWriter();
        Collatz.solve(r, w);
        Assert.assertTrue(w.toString().equals("11 11 15\n"));}

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
