// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
    
    public void testRead2 () {
    	final Scanner r = new Scanner("/n");
    	final int a[] = {0, 0};
    	final boolean b = Collatz.read(r, a);
    	Assert.assertTrue(b == false);
    	Assert.assertTrue(a[0] == 0);
    	Assert.assertTrue(a[1] == 0);
    }
    
    public void testRead3 () {
    	final Scanner r = new Scanner("10 100\n");
    	final int a[] = {0, 0};
    	final boolean b = Collatz.read(r, a);
    	Assert.assertTrue(b == true);
    	Assert.assertTrue(a[0] == 10);
    	Assert.assertTrue(a[1] == 100);
    }

    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}

    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
    
    public void testPrint2 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 100, 200, 25);
    	Assert.assertTrue(w.toString().equals("100 200 25\n"));}
    
    public void testPrint3 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 201, 210, 89);
    	Assert.assertTrue(w.toString().equals("201 210 89\n"));}

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
    
    public void testSolve2 () throws IOException {
    	final Scanner r = new Scanner("5 15\n16 20\n21 25\n26 30\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);					
    	Assert.assertTrue(w.toString().equals("5 15 20\n16 20 21\n21 25 24\n26 30 112\n"));
    }
    
    public void testSolve3 () throws IOException {
    	final Scanner r = new Scanner("500 600\n700 800\n900 1000\n1200 1300\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("500 600 137\n700 800 171\n900 1000 174\n1200 1300 177\n"));
    }

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
