// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
 */

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
	// ----
	// read
	// ----

	public void testRead () {
		final Scanner r   = new Scanner("1 10\n");
		final int     a[] = {0, 0};
		final boolean b   = Collatz.read(r, a);
		Assert.assertTrue(b    == true);
		Assert.assertTrue(a[0] ==    1);
		Assert.assertTrue(a[1] ==   10);
	}
	
	// ----
	// elliot's read tests
	// ----

	public void testReadEnd () {
		final Scanner r   = new Scanner("");
		final int     a[] = {0, 0};
		final boolean b   = Collatz.read(r, a);
		Assert.assertTrue(b    == false);
	}
	
	public void testReadPreservesOrder () {
		final Scanner r   = new Scanner("10 1\n");
		final int     a[] = {0, 0};
		final boolean b   = Collatz.read(r, a);
		Assert.assertTrue(b    == true);
		Assert.assertTrue(a[0] ==   10);
		Assert.assertTrue(a[1] ==   1);
	}

	// ----
	// eval
	// ----

	public void testEval1 () {
		final int v = Collatz.eval(1, 10);
		Assert.assertTrue(v == 20);
	}

	public void testEval2 () {
		final int v = Collatz.eval(100, 200);
		Assert.assertTrue(v == 125);
	}

	public void testEval3 () {
		final int v = Collatz.eval(201, 210);
		Assert.assertTrue(v == 89);
	}
	
	// ----
	// elliot's eval tests
	// ----

	public void testEvalReversed () {
		final int v = Collatz.eval(10, 1);
		Assert.assertTrue(v == 20);
	}

	public void testEvalSameNum () {
		final int v = Collatz.eval(1, 1);
		Assert.assertEquals(1, v);
	}

	// -----
	// print
	// -----

	public void testPrint () throws IOException {
		final Writer w = new StringWriter();
		Collatz.print(w, 1, 10, 20);
		Assert.assertTrue(w.toString().equals("1 10 20\n"));
	}
	
	public void testPrint2 () throws IOException {
		final Writer w = new StringWriter();
		Collatz.print(w, 1, 10, 20);
		Collatz.print(w, 100, 200, 125);
		Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n"));
	}
	
	public void testPrintPreservesOrder () throws IOException {
		final Writer w = new StringWriter();
		Collatz.print(w, 1, 10, 20);
		Collatz.print(w, 200, 100, 125);
		Assert.assertTrue(w.toString().equals("1 10 20\n200 100 125\n"));
	}

	// -----
	// solve
	// -----

	public void testSolve () throws IOException {
		final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
		final Writer  w = new StringWriter();
		Collatz.solve(r, w);
		Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));
	}
	
	public void testSolveWithOne () throws IOException {
		final Scanner r = new Scanner("1 10\n");
		final Writer  w = new StringWriter();
		Collatz.solve(r, w);
		Assert.assertTrue(w.toString().equals("1 10 20\n"));
	}
	
	public void testSolveEmpty () throws IOException {
		final Scanner r = new Scanner("");
		final Writer  w = new StringWriter();
		Collatz.solve(r, w);
		Assert.assertTrue(w.toString().equals(""));
	}
	
	// ----
	// tests for private methods
	// ----
	
	public void testCalcCycleLength() {
		final int v = Collatz.calcCycleLength(10);
		Assert.assertEquals(v,7);
	}
	
	public void testCalcCycleLength2() {
		final int v = Collatz.calcCycleLength(1);
		Assert.assertEquals(v,1);
	}
	
	public void testCalcCycleLengthJustDivides() {
		final int v = Collatz.calcCycleLength(128);
		Assert.assertEquals(v,8);
	}

	// ----
	// main
	// ----

	public static void main (String[] args) {
		System.out.println("TestCollatz.java");
		TestRunner.run(new TestSuite(TestCollatz.class));
		System.out.println("Done.");}}
