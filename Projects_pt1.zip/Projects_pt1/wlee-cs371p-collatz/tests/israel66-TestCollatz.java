// ---------------------------------
// TestCollatz.java
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {

    // ----
    // read
    // ----

    public void testReadSmall () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}

    public void testEmptyRead	 () {
        final Scanner r   = new Scanner("\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == false);
    	Assert.assertTrue(a[0] ==    0);
    	Assert.assertTrue(a[1] ==   0);}

    public void testEmpty2Read	 () {
        final Scanner r   = new Scanner("");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == false);
    	Assert.assertTrue(a[0] ==    0);
    	Assert.assertTrue(a[1] ==   0);}

    public void testRevReadSmall () {
        final Scanner r   = new Scanner("10 1\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    10);
    	Assert.assertTrue(a[1] ==   1);}

    public void testFullRangeRead2 () {
        final Scanner r   = new Scanner("1 1000000\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   1000000);}

    public void testMidRangeRead1	 () {
        final Scanner r   = new Scanner("250000 750000\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    250000);
    	Assert.assertTrue(a[1] ==   750000);}

    public void testMidRangeRead2	 () {
        final Scanner r   = new Scanner("2578 768234\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    2578);
    	Assert.assertTrue(a[1] ==   768234);}

    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}

    // My Unit Tests fo Eval

    public void testIntOverFlow (){
      final int v = Collatz.eval(100000,200000);
      Assert.assertTrue(v==383);
    }
	
    public void testIntOverFlow2 (){
      final int v = Collatz.eval(1,1000000);
      Assert.assertTrue(v==525);
    }

    public void testIntOverFlow3 (){
      final int v = Collatz.eval(1000000,1);
      Assert.assertTrue(v==525);
    }

    public void testOneToOne (){
      final int v = Collatz.eval(1,1);
      Assert.assertTrue(v==1);
    }

	public void testTen (){
      final int v = Collatz.eval(10, 10);
      Assert.assertTrue(v==7);
    }

	public void testfiveSevenEightFive (){
      final int v = Collatz.eval(5875, 5875);
      Assert.assertTrue(v==55);
    }

	public void testLowRange (){
      final int v = Collatz.eval(37, 200098);
      Assert.assertTrue(v==383);
    }

	public void testLowRange2 (){
      final int v = Collatz.eval(9984, 1043);
      Assert.assertTrue(v==262);
    }


    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}

    //my tests

    public void testPrintMillion () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 1000000, 525);
    	Assert.assertTrue(w.toString().equals("1 1000000 525\n"));}

    public void testPrintMillion2 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1000000, 1, 525);
    	Assert.assertTrue(w.toString().equals("1000000 1 525\n"));}

    public void testPrintTwelve () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 12, 12, 12);
    	Assert.assertTrue(w.toString().equals("12 12 12\n"));}

	public void testPrintOnes () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 1, 1);
    	Assert.assertTrue(w.toString().equals("1 1 1\n"));}

	public void testPrintBiggerNumbers () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1000000, 111111, 222222);
    	Assert.assertTrue(w.toString().equals("1000000 111111 222222\n"));}

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}

    //my tests
    public void testSolveIntOverFlow () throws IOException {
        final Scanner r = new Scanner("100000 200000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("100000 200000 383\n"));}
	
    public void testSolveIntOverFlowReverse () throws IOException {
        final Scanner r = new Scanner("1 1000000\n1000000 1\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 1000000 525\n1000000 1 525\n"));}

    public void testBeginning () throws IOException {
        final Scanner r = new Scanner("1 1\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 1 1\n"));}

	public void testSolveMedium () throws IOException {
        final Scanner r = new Scanner("93365 94969\n264990 344260\n199086 391744\n486043 486712\n348743 557938\n52175 59356\n72770 83098\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("93365 94969 315\n264990 344260 407\n199086 391744 443\n486043 486712 320\n348743 557938 470\n52175 59356 340\n72770 83098 351\n"));}

	public void testSolveNext () throws IOException {
        final Scanner r = new Scanner("100001 100010\n900 1000\n100000 200000\n100000 200000\n100000 300000\n1 10\n100 200\n201 210\n10 10\n5875 5875\n37 200098\n9984 1043\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("100001 100010 310\n900 1000 174\n100000 200000 383\n100000 200000 383\n100000 300000 443\n1 10 20\n100 200 125\n201 210 89\n10 10 7\n5875 5875 55\n37 200098 383\n9984 1043 262\n"));}
    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
