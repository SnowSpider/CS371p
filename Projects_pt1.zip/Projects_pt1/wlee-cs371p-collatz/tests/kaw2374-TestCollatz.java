// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
 */

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
	// ----
	// read (10 tests)
	// ----

	public void testRead1 () {
		final Scanner r   = new Scanner("1 10\n");
		final int     a[] = {0, 0};
		final boolean b   = Collatz.read(r, a);
		Assert.assertTrue(b    == true);
		Assert.assertTrue(a[0] ==    1);
		Assert.assertTrue(a[1] ==   10);
	}

	public void testRead2(){
		final Scanner r   = new Scanner("10 1\n");
		final int     a[] = {0, 0};
		final boolean b   = Collatz.read(r, a);
		Assert.assertTrue(b    == true);
		Assert.assertTrue(a[0] ==    10);
		Assert.assertTrue(a[1] ==   1);
	}
	public void testRead3(){
		final Scanner r   = new Scanner("100 11234\n");
		final int     a[] = {0, 0};
		final boolean b   = Collatz.read(r, a);
		Assert.assertTrue(b    == true);
		Assert.assertTrue(a[0] ==    100);
		Assert.assertTrue(a[1] ==   11234);
	}
	public void testRead4(){
		final Scanner r   = new Scanner("\n");
		final int     a[] = {0, 0};
		final boolean b   = Collatz.read(r, a);
		Assert.assertTrue(b != true);
	}
	public void testRead5(){
		final Scanner r   = new Scanner("110");
		final int     a[] = {0, 0};
		final boolean b   = Collatz.read(r, a);
		Assert.assertTrue(b != true);
	}
	public void testRead6(){
		final Scanner r   = new Scanner("a2#$");
		final int     a[] = {0, 0};
		final boolean b   = Collatz.read(r, a);
		Assert.assertTrue(b != true);
	}
	public void testRead7(){
		final Scanner r   = new Scanner("");
		final int     a[] = {0, 0};
		final boolean b   = Collatz.read(r, a);
		Assert.assertTrue(b != true);
	}
	public void testRead8(){
		final Scanner r   = new Scanner("22 \t 48 \r\n");
		final int     a[] = {0, 0};
		final boolean b   = Collatz.read(r, a);
		Assert.assertTrue(b == true);
		Assert.assertTrue(a[0] == 22);
		Assert.assertTrue(a[1] == 48);
	}
	public void testRead9(){
		final Scanner r   = new Scanner("\t\r\n");
		final int     a[] = {0, 0};
		final boolean b   = Collatz.read(r, a);
		Assert.assertTrue(b != true);
	}

	// ----
	// eval (15 tests)
	// ----

	public void testEval1 () {
		final int v = Collatz.eval(1, 10);
		Assert.assertTrue(v == 20);}

	public void testEval2 () {
		final int v = Collatz.eval(100, 200);
		Assert.assertTrue(v == 125);
	}
	public void testEval3 () {
		final int v = Collatz.eval(201, 210);
		Assert.assertTrue(v == 89);
	}

	public void testEval4 () {
		final int v = Collatz.eval(100, 100);
		Assert.assertTrue(v == 26);
	}
	public void testEval5 () {
		final int v = Collatz.eval(900, 1000);
		Assert.assertTrue(v == 174);
	}
	public void testEval6 () {
		final int v = Collatz.eval(159487, 159487);
		Assert.assertTrue(v == 184);
	}
	public void testEval7 () {
		final int v = Collatz.eval(1, 200000);
		Assert.assertTrue(v == 383);
	}
	public void testEval8 () {
		final int v = Collatz.eval(1,1);
		Assert.assertTrue(v == 1);
	}
	public void testEval9 () {
		final int v = Collatz.eval(3,3);
		Assert.assertTrue(v == 8);
	}
	public void testEval10 () {
		int sum = 0;
		for (int i = 1; i <= 10; i++)
			sum += Collatz.eval(i,i);
		Assert.assertTrue(sum == 77);
	}
	public void testEval12 () {
		final int v1 = Collatz.eval(576, 1538);
		final int v2 = Collatz.eval(570, 1550);
		Assert.assertTrue(v2 >= v1);
	}
	public void testEval13 () {
		final int v1 = Collatz.eval(50, 100);
		final int v2 = Collatz.eval(1, 100);
		Assert.assertTrue(v1 == v2);
	}
	public void testEval14 (){
		final int v1 = Collatz.eval(1, 1000);
		final int v2 = Collatz.eval(500, 1000);
		Assert.assertTrue(v1 == v2);
	}
	public void testEval15 () {
		final int v1 = Collatz.eval(10, 1);
		Assert.assertTrue (v1 == 20);
	}
	
	// ----
	// evalHelp (5 tests)
	//----
	
	
	public void testEvalHelp () {
		final int v1 = Collatz.evalHelp(1);
		Assert.assertTrue (v1 == 1);
	}
	public void testEvalHelp2 () {
		final int v1 = Collatz.evalHelp(100);
		Assert.assertTrue (v1 == 26);
	}
	public void testEvalHelp3 () {
		final int v1 = Collatz.evalHelp(3);
		Assert.assertTrue (v1 == 8);
	}
	public void testEvalHelp4 () {
		final int v1 = Collatz.evalHelp(10);
		Assert.assertTrue (v1 == 7);
	}
	public void testEvalHelp5 () {
		final int v1 = Collatz.evalHelp(16);
		Assert.assertTrue (v1 == 5);
	}

	// -----
	// print (7 tests)
	// -----

	public void testPrint1 () throws IOException {
		final Writer w = new StringWriter();
		Collatz.print(w, 1, 10, 20);
		Assert.assertTrue(w.toString().equals("1 10 20\n"));
	}
	public void testPrint2() throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 100, 200, 125);
        Assert.assertTrue(w.toString().equals("100 200 125\n"));
    }
    public void testPrint3() throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 201, 210, 89);
        Assert.assertTrue(w.toString().equals("201 210 89\n"));
    }
    public void testPrint4() throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1000, 900, 174);
        Assert.assertTrue(w.toString().equals("1000 900 174\n"));
    }
    public void testPrint5() throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 159487, 159487, 184);
        Assert.assertTrue(w.toString().equals("159487 159487 184\n"));
    }
    public void testPrint6() throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, -1, 2, 3);
        Assert.assertTrue(w.toString().equals("-1 2 3\n"));
    }
    public void testPrint7() throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 10, 1, 20);
        Assert.assertTrue(w.toString().equals("10 1 20\n"));
    }

	// -----
	// solve (5 tests)
	// -----

	public void testSolve1 () throws IOException {
		final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
		final Writer  w = new StringWriter();
		Collatz.solve(r, w);
		Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));
	}
	public void testSolve2 () throws IOException {
        final Scanner r = new Scanner("1 200000\n200001 400000\n400001 600000\n600001 800000\n800001 999999\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
        Assert.assertTrue(w.toString().equals("1 200000 383\n200001 400000 443\n400001 600000 470\n600001 800000 509\n800001 999999 525\n"));
    }
    public void testSolve3 () throws IOException {
        final Scanner r = new Scanner("1 1\n2 2\n3 3\n4 4\n5 5\n6 6\n7 7\n8 8\n9 9\n10 10\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
        Assert.assertTrue(w.toString().equals("1 1 1\n2 2 2\n3 3 8\n4 4 3\n5 5 6\n6 6 9\n7 7 17\n8 8 4\n9 9 20\n10 10 7\n"));
    }
    public void testSolve4 () throws IOException {
        final Scanner r = new Scanner("2154 40254\n75594 81000\n82450 130131\n146877 132000\n160475 195590\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
        Assert.assertTrue(w.toString().equals("2154 40254 324\n75594 81000 351\n82450 130131 354\n146877 132000 375\n160475 195590 365\n"));
    }
    public void testSolve5 () throws IOException {
        final Scanner r = new Scanner("200145 230000\n245067 266287\n274340 302660\n294422 357583\n367489 395554\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
        Assert.assertTrue(w.toString().equals("200145 230000 386\n245067 266287 407\n274340 302660 389\n294422 357583 441\n367489 395554 436\n"));
    }

	// ----
	// main
	// ----

	public static void main (String[] args) {
		System.out.println("TestCollatz.java");
		TestRunner.run(new TestSuite(TestCollatz.class));
		System.out.println("Done.");}}