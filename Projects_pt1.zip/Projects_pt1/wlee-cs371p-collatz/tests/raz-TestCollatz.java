// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead1 () {
        final Scanner r   = new Scanner("23001 24000\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    ==  true);
    	Assert.assertTrue(a[0] == 23001);
    	Assert.assertTrue(a[1] == 24000);}

    public void testRead2 () {
        final Scanner r   = new Scanner("997001 998000\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    ==   true);
    	Assert.assertTrue(a[0] == 997001);
    	Assert.assertTrue(a[1] == 998000);}

    public void testRead3 () {
        final Scanner r   = new Scanner("1 1000000\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    ==    true);
    	Assert.assertTrue(a[0] ==       1);
    	Assert.assertTrue(a[1] == 1000000);}

    // ----
    // calc
    // ----

    public void testCalc1 () {
        final int v = Collatz.calc(473843);
    	Assert.assertTrue(v == 214);}

    public void testCalc2 () {
        final int v = Collatz.calc(997823);
    	Assert.assertTrue(v == 440);}

    public void testCalc3 () {
        final int v = Collatz.calc(1000000);
    	Assert.assertTrue(v == 153);}

    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(23001, 24000);
    	Assert.assertTrue(v == 282);}

    public void testEval2 () {
        final int v = Collatz.eval(997001, 998000);
    	Assert.assertTrue(v == 440);}

    public void testEval3 () {
        final int v = Collatz.eval(1, 1000000);
    	Assert.assertTrue(v == 525);}


    // -----
    // print
    // -----

    public void testPrint1 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 23001, 24000, 282);
    	Assert.assertTrue(w.toString().equals("23001 24000 282\n"));}

    public void testPrint2 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 997001, 998000, 440);
    	Assert.assertTrue(w.toString().equals("997001 998000 440\n"));}

    public void testPrint3 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 1000000, 525);
    	Assert.assertTrue(w.toString().equals("1 1000000 525\n"));}

    // -----
    // solve
    // -----

    public void testSolve1 () throws IOException {
        final Scanner r = new Scanner("23001 24000\n997001 998000\n1 1000000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("23001 24000 282\n997001 998000 440\n1 1000000 525\n"));}

    public void testSolve2 () throws IOException {
        final Scanner r = new Scanner("23001 24000\n998000 997001\n1 1000000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("23001 24000 282\n998000 997001 440\n1 1000000 525\n"));}

    public void testSolve3 () throws IOException {
        final Scanner r = new Scanner("24000 23001\n998000 997001\n1000000 1\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("24000 23001 282\n998000 997001 440\n1000000 1 525\n"));}

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
