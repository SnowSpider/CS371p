// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % export CLASSPATH=.:$CLASSPATH:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // --------
    // read (8)
    // --------

    public void testRead_Basic () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);
    }
    public void testRead_Backwards () {
        final Scanner r   = new Scanner("10 1\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    10);
    	Assert.assertTrue(a[1] ==   1);
    }
    public void testRead_LargeValues () {
        final Scanner r   = new Scanner("100 11234\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    100);
    	Assert.assertTrue(a[1] ==   11234);
    }
    public void testRead_FailNewLine () {
	final Scanner r   = new Scanner("\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b != true);
    }
    public void testRead_FailOneValue () {
	final Scanner r   = new Scanner("110");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b != true);
    }
    public void testRead_FailCharacters () {
	final Scanner r   = new Scanner("a2#$");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b != true);
    }
    public void testRead_FailEmptyString () {
	final Scanner r   = new Scanner("");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b != true);
    }
    public void testRead_WhiteSpace () {
	final Scanner r   = new Scanner("22 \t 48 \r\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b == true);
	Assert.assertTrue(a[0] == 22);
	Assert.assertTrue(a[1] == 48);
    }

    // ---------
    // eval (11)
    // ---------

    public void testEval_Small () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);
    }
    public void testEval_WhichHasMax () {
	final int v = Collatz.eval(1, 10);
	final int i = Collatz.eval(9, 9);
	Assert.assertTrue(v == i);
    }
    public void testEval_Backwards () {
	final int v = Collatz.eval(1, 10);
	final int j = Collatz.eval(10, 1);
	Assert.assertTrue(v == j);
    }
    public void testEval_Medium () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);
    }
    public void testEval_Small1 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);
    }
    public void testEval_Medium2 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);
    }
    public void testEval_DebugOverflow1 () {
	final int v = Collatz.eval(1, 200000);
	Assert.assertTrue(v == 383);
    }
    public void testEval_RangesComparison () {
	final int v1 = Collatz.eval(576, 1538);
	final int v2 = Collatz.eval(570, 1550);
	Assert.assertTrue(v2 >= v1);
    }
    public void testEval_RangesTrick () {
	final int v1 = Collatz.eval(50, 100);
	final int v2 = Collatz.eval(1, 100);
	Assert.assertTrue(v1 == v2);
    }
    public void testEval_HandleOverMil () {
	final int v = Collatz.eval(1000000, 1010000);
	Assert.assertTrue(v == 489);
    }
    public void testEvale_DebugOverflow_Piazza55 () {
	final int v1 = Collatz.eval(232545, 681701);
	final int v2 = Collatz.eval(773104, 675975);
	Assert.assertTrue(v1 == 509);
	Assert.assertTrue(v2 == 504);
    }

    // ---------------
    // cycleLength (9)
    // ---------------

    public void testCycleLength_CondtionFor1 () {
	final int v = Collatz.cycleLength(1, 0);
	Assert.assertTrue(v == 1);
    }
    public void testCycleLength_WhichHasMax () {
	final int v = Collatz.cycleLength(9, 0);
	Assert.assertTrue(v == 20);
    }
    public void testCycleLength_ClassExample () {
	final int v = Collatz.cycleLength(3, 0);
	Assert.assertTrue(v == 8);
    }
    public void testCycleLength_EachValueInRange () {
	int sum = 0;
	for (int i = 1; i <= 10; i++)
	    sum += Collatz.cycleLength(i, 0);
	Assert.assertTrue(sum == 77);
    }
    public void testCycleLength_DebugOverflow1 () {
	final int v = Collatz.cycleLength(159487, 0);
	Assert.assertTrue(v == 184);
    }
    public void testCycleLength_DebugOverflow2 () {
	final int v = Collatz.cycleLength(113383, 0);
	Assert.assertTrue(v == 248);
    }
    public void testCycleLength_DebugOverflow3 () {
	final int v = Collatz.cycleLength(997823, 0);
	Assert.assertTrue(v == 440);
    }
    public void testCycleLength_Million	() {
	final int v = Collatz.cycleLength(1000000, 0);
	Assert.assertTrue(v == 153);
    }
    public void testCycleLength_Huge () {
	final int v = Collatz.cycleLength(1200000000, 0);
	Assert.assertTrue(v == 109);
    }

    // ---------
    // print (4)
    // ---------

    public void testPrint_Basic () throws IOException {
        final Writer w = new StringWriter();
        try{
	    Collatz.print(w, 1, 10, 20);
	    Assert.assertTrue(w.toString().equals("1 10 20\n"));
	}catch(IOException e){
	    Assert.fail("Exception in print().");
	}	
    }
    public void testPrint_WrongAns () throws IOException {
        final Writer w = new StringWriter();
	try{
	    Collatz.print(w, 100, 200, 12);
    	    Assert.assertTrue(!w.toString().equals("100 200 125\n"));
	}catch(IOException e){
	    Assert.fail("Exception in print().");
	}
    }
    public void testPrint_Reverse () throws IOException {
        final Writer w = new StringWriter();
	try{
            Collatz.print(w, 1000, 900, 174);
    	    Assert.assertTrue(w.toString().equals("1000 900 174\n"));
	}catch(IOException e){
	    Assert.fail("Exception in print().");
	}
    }
    public void testPrint_OverMil () throws IOException {
	final Writer w = new StringWriter();
	try{
	Collatz.print(w, 1450000, 2000000, 557);
	Assert.assertTrue(w.toString().equals("1450000 2000000 557\n"));
	}catch(IOException e){
	    Assert.fail("Exception in print().");
	}
    }

    // ---------
    // solve (5)
    // ---------

    public void testSolve_Basic () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
	try{
            Collatz.solve(r, w);
    	    Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));
	}catch(IOException e){
	    Assert.fail("Exception in solve().");
	}
    }
    public void testSolve_200k () throws IOException {
        final Scanner r = new Scanner("1 200000\n200001 400000\n400001 600000\n600001 800000\n800001 999999\n");
        final Writer  w = new StringWriter();
	try{
            Collatz.solve(r, w);
    	    Assert.assertTrue(w.toString().equals("1 200000 383\n200001 400000 443\n400001 600000 470\n600001 800000 509\n800001 999999 525\n"));
	}catch(IOException e){
	    Assert.fail("Exception in solve().");
	}

    }
    public void testSolve_Small () throws IOException {
        final Scanner r = new Scanner("1 1\n2 2\n3 3\n4 4\n5 5\n6 6\n7 7\n8 8\n9 9\n10 10\n");
        final Writer  w = new StringWriter();
        try{
	    Collatz.solve(r, w);
    	    Assert.assertTrue(w.toString().equals("1 1 1\n2 2 2\n3 3 8\n4 4 3\n5 5 6\n6 6 9\n7 7 17\n8 8 4\n9 9 20\n10 10 7\n"));
	}catch(IOException e){
	    Assert.fail("Exception in solve().");
	}

    }
    public void testSolve_Overflow1 () throws IOException {
        final Scanner r = new Scanner("2154 40254\n75594 81000\n82450 130131\n146877 132000\n160475 195590\n");
        final Writer  w = new StringWriter();
        try{
	    Collatz.solve(r, w);
    	    Assert.assertTrue(w.toString().equals("2154 40254 324\n75594 81000 351\n82450 130131 354\n146877 132000 375\n160475 195590 365\n"));
	}catch(IOException e){
	    Assert.fail("Exception in solve().");
	}

    }
    public void testSolve_Overflow2 () throws IOException {
        final Scanner r = new Scanner("200145 230000\n245067 266287\n274340 302660\n294422 357583\n367489 395554\n");
        final Writer  w = new StringWriter();
        try{
	    Collatz.solve(r, w);
    	    Assert.assertTrue(w.toString().equals("200145 230000 386\n245067 266287 407\n274340 302660 389\n294422 357583 441\n367489 395554 436\n"));
	}catch(IOException e){
	    Assert.fail("Exception in solve().");
	}

    }

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
