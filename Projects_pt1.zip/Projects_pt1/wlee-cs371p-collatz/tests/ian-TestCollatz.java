// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {

    // -----
    // print
    // -----

    public void testPrintOneLine() throws IOException {
        final Writer writer = new StringWriter();
        Collatz.print(writer, 1, 10, 20);
        Assert.assertTrue(writer.toString().equals("1 10 20\n"));
    }

    public void testPrintMultipleLines() throws IOException {
        final Writer writer = new StringWriter();
        Collatz.print(writer, 1, 10, 20);
        Collatz.print(writer, 1, 1, 1);
        Assert.assertTrue(writer.toString().equals("1 10 20\n1 1 1\n"));
    }

    public void testPrintIllogical() throws IOException {
        final Writer writer = new StringWriter();
        Collatz.print(writer, 10, 1, 55);
        Assert.assertTrue(writer.toString().equals("10 1 55\n"));
    }

    // -----
    // solve
    // -----

    public void testSolveMultiline() throws IOException {
        final Scanner scanner = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer writer = new StringWriter();
        Collatz.solve(scanner, writer);
        Assert.assertTrue(writer.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));
    }

    public void testSolveSingleLine() throws IOException {
        final Scanner scanner = new Scanner("1 10\n");
        final Writer writer = new StringWriter();
        Collatz.solve(scanner, writer);
        Assert.assertTrue(writer.toString().equals("1 10 20\n"));
    }

    public void testSolveNoTerminalNewline() throws IOException {
        final Scanner scanner = new Scanner("1 10");
        final Writer writer = new StringWriter();
        Collatz.solve(scanner, writer);
        Assert.assertTrue(writer.toString().equals("1 10 20\n"));
    }

    public void testSolveBlankLines() throws IOException {
        final Scanner scanner = new Scanner("1 10\n\n1 10\n");
        final Writer writer = new StringWriter();
        Collatz.solve(scanner, writer);
        Assert.assertTrue(writer.toString().equals("1 10 20\n1 10 20\n"));
    }

    // -----
    // read
    // -----

    public void testReadMultiline() {
        final Scanner scanner = new Scanner("1 10\n10 1\n10 10\n");
        final int range[] = {0, 0};
        Assert.assertEquals(true, Collatz.read(scanner, range));
        Assert.assertEquals(1, range[0]);
        Assert.assertEquals(10, range[1]);
        Assert.assertEquals(true, Collatz.read(scanner, range));
        Assert.assertEquals(10, range[0]);
        Assert.assertEquals(1, range[1]);
        Assert.assertEquals(true, Collatz.read(scanner, range));
        Assert.assertEquals(10, range[0]);
        Assert.assertEquals(10, range[1]);
        Assert.assertEquals(false, Collatz.read(scanner, range));
        Assert.assertEquals(10, range[0]);
        Assert.assertEquals(10, range[1]);
    }

    public void testReadNoTerminalNewline() {
        final Scanner scanner = new Scanner("1 10");
        final int range[] = {0, 0};
        Assert.assertEquals(true, Collatz.read(scanner, range));
        Assert.assertEquals(1, range[0]);
        Assert.assertEquals(10, range[1]);
    }

    public void testReadSingleLine() {
        final Scanner scanner = new Scanner("50 50\n");
        final int range[] = {0, 0};
        Assert.assertEquals(true, Collatz.read(scanner, range));
        Assert.assertEquals(50, range[0]);
        Assert.assertEquals(50, range[1]);
    }

    // ----
    // eval
    // ----

    public void testEvalOne() { Assert.assertEquals(1, Collatz.eval(1, 1)); }
    public void testEvalNonCachedRange() { Assert.assertEquals(20, Collatz.eval(1, 10)); }
    public void testEvalSingle() { Assert.assertEquals(7, Collatz.eval(10, 10)); }
    public void testEvalEntireRange() { Assert.assertEquals(525, Collatz.eval(1, 1000000)); }
    public void testEvalRangeThatIntescectsMax() { Assert.assertEquals(525, Collatz.eval(345262, 959069)); }
    public void testEvalLargestOverflowingNumber() { Assert.assertEquals(440, Collatz.eval(997823, 997823)); }

    // ----
    // getCycleLength
    // ----

    public void testGetCycleLengthOne() { Assert.assertEquals(1, Collatz.getCycleLength(1)); }
    public void testGetCycleLengthPowerOfTwo() { Assert.assertEquals(9, Collatz.getCycleLength(256)); }
    public void testGetCycleLengthSignedInt32Overflow() { Assert.assertEquals(248, Collatz.getCycleLength(113383)); } // overflows a signed 32 bit integer
    public void testGetCycleLengthUnsignedInt32OverflowMin() { Assert.assertEquals(184, Collatz.getCycleLength(159487)); } // the smallest number that overflows an unsigned 32 bit integer
    public void testGetCycleLengthUnsignedInt32OverflowMax() { Assert.assertEquals(440, Collatz.getCycleLength(997823)); } // the largest number (<= 1000000) that overflows an unsigned 32 bit integer
    public void testGetCycleLengthMax() { Assert.assertEquals(525, Collatz.getCycleLength(837799)); }

    // ----
    // heapSearch
    // ----

    public void testHeapSearchNonCachedSingle() { Assert.assertEquals(0, Collatz.heapSearch(1, 1)); }
    public void testHeapSearchMaxSingle() { Assert.assertEquals(525, Collatz.heapSearch(837799, 837799)); }
    public void testHeapSearchMaxIntersectingRange() { Assert.assertEquals(525, Collatz.heapSearch(837789, 837809)); }
    public void testHeapSearchNonCachedRange() { Assert.assertEquals(0, Collatz.heapSearch(939496, 939496)); }
    public void testHeapSearchEntireRange() { Assert.assertEquals(525, Collatz.heapSearch(1, 1000000)); }
    public void testHeapSearchUpToMax() { Assert.assertEquals(525, Collatz.heapSearch(1, 837799)); }
    public void testHeapSearchUpFromMax() { Assert.assertEquals(525, Collatz.heapSearch(837799, 1000000)); }

    // ----
    // main
    // ----

    public static void main(String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");
    }
}
