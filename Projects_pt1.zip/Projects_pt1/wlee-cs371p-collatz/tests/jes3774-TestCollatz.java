// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}


    public void testRead_backwardInput () {
        final Scanner r   = new Scanner("10 1\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==   10);
    	Assert.assertTrue(a[1] ==    1);}


    public void testRead_maxAndMin () {
        final Scanner r   = new Scanner("1 1000000\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   1000000);}


    public void testRead_genericInput () {
        final Scanner r   = new Scanner("12345 67890\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    12345);
    	Assert.assertTrue(a[1] ==   67890);}

    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}

    public void testEval_backwardInput () {
        final int v = Collatz.eval(10, 1);
    	Assert.assertTrue(v == 20);}

    public void testEval_genericDoubleInput () {
        final int v = Collatz.eval(888, 888);
    	Assert.assertTrue(v == 73);}

    public void testEval_maxRange () {
        final int v = Collatz.eval(1, 1000000);
    	Assert.assertTrue(v == 525);}

    public void testEval_minDoubleInput () {
        final int v = Collatz.eval(1, 1);
    	Assert.assertTrue(v == 1);}

    public void testEval_maxDoubleInput () {
        final int v = Collatz.eval(1000000, 1000000);
    	Assert.assertTrue(v == 153);}

	// -------
	// evalOne
	// -------

    public void testEvalOne_min () {
        final int v = Collatz.evalOne(1);
    	Assert.assertTrue(v == 1);}

    public void testEvalOne_max () {
        final int v = Collatz.evalOne(1000000);
    	Assert.assertTrue(v == 153);}

    public void testEvalOne_genericEven () {
        final int v = Collatz.evalOne(54498);
    	Assert.assertTrue(v == 66);}

    public void testEvalOne_genericOdd () {
        final int v = Collatz.evalOne(54499);
    	Assert.assertTrue(v == 66);}

    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}

    public void testPrint_MaxDouble () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1000000, 1000000, 153);
    	Assert.assertTrue(w.toString().equals("1000000 1000000 153\n"));}

    public void testPrint_GenericDouble () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 888, 888, 73);
    	Assert.assertTrue(w.toString().equals("888 888 73\n"));}

    public void testPrint_MaxRange () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 1000000, 525);
    	Assert.assertTrue(w.toString().equals("1 1000000 525\n"));}

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}

    public void testSolve_Generic () throws IOException {
        final Scanner r = new Scanner("14 16\n20 40\n40 60\n60 80\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("14 16 18\n20 40 112\n40 60 113\n60 80 116\n"));}

    public void testSolve_EdgeCases () throws IOException {
        final Scanner r = new Scanner("1 2\n999999 1000000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 2 2\n999999 1000000 259\n"));}

    public void testSolve3_BackwardInput () throws IOException {
        final Scanner r = new Scanner("1000000 1000000\n1000 900\n210 201\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1000000 1000000 153\n1000 900 174\n210 201 89\n"));}

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
