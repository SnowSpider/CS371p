// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead_standard () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
    	
    	 public void testRead_reverseInput () {
        final Scanner r   = new Scanner("10 1\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==   10);
    	Assert.assertTrue(a[1] ==   1);}
    	
    	 public void testRead_extraSpace () {
        final Scanner r   = new Scanner("1 \t 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==   1);
    	Assert.assertTrue(a[1] ==   10);}
    	
    	 public void testRead_emptyString () {
        final Scanner r   = new Scanner("");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == false);
    	}

	 public void testRead_garbageValue () {
        final Scanner r   = new Scanner("asdfg");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == false);
    	}

  /* Test for my function RecLen */
      public void test_reclen_standard() {
        final int v = Collatz.recLen(9);
        Assert.assertTrue(v == 20);
        }
        
        public void test_reclen_maximumValue() {
        final int v = Collatz.recLen(999999);
        Assert.assertTrue(v == 259);
        }
        

	public void test_reclen_overflowValue() {
        final int v = Collatz.recLen(997823);
        Assert.assertTrue(v == 440);
        }
    // ----
    // eval
    // ----

    public void testEval_completeRange () {
        final int v = Collatz.eval(1, 999999);
    	Assert.assertTrue(v == 525);}

    public void testEval_minValue () {
        final int v = Collatz.eval(1, 1);
    	Assert.assertTrue(v == 1);}

    public void testEval_reverseInput () {
        final int v = Collatz.eval(999999, 1);
    	Assert.assertTrue(v == 525);}

    public void testEval_subsetInclusion () {
        final int v = Collatz.eval(50 , 100);
        final int u = Collatz.eval(1 ,200);
    	Assert.assertTrue(v <= u);}
    	
    	   public void testEval_largeIntegers () {
        final int v = Collatz.eval(999999 , 1000000);
        final int u = Collatz.eval(999999 ,999999);
    	Assert.assertTrue(v >= u);}

    // -----
    // print
    // -----

    public void testPrint_standard () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
    	
    	public void testPrint_reverseValues () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 10, 1, 20);
    	Assert.assertTrue(w.toString().equals("10 1 20\n"));}
    	
    	public void testPrint_completeRange () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 999999, 525);
    	Assert.assertTrue(w.toString().equals("1 999999 525\n"));}

    // -----
    // solve
    // -----

    public void testSolve_standard () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
    	
    	public void testSolve_reverseValue () throws IOException {
        final Scanner r = new Scanner("999999 10\n10 999999\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("999999 10 525\n10 999999 525\n"));}
    	
    	public void testSolve_singlePoint () throws IOException {
        final Scanner r = new Scanner("1 1\n999999 999999\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 1 1\n999999 999999 259\n"));}
    	
    	public void testSolve_formatCheck () throws IOException {
        final Scanner r = new Scanner("\t1 \t \t \t 10\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
    	
    	

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
