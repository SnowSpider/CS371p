// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {

    // ----
    // read
    // ----

    public void testReadSample () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b    == true);
        Assert.assertTrue(a[0] ==    1);
        Assert.assertTrue(a[1] ==   10);}

	public void testReadSame () {
        final Scanner r   = new Scanner("7 7\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b    == true);
        Assert.assertTrue(a[0] ==  	7);
        Assert.assertTrue(a[1] ==   7);}

	public void testReadHigh () {
        final Scanner r   = new Scanner("500500 600600\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b    == true);
        Assert.assertTrue(a[0] ==	500500);
        Assert.assertTrue(a[1] ==   600600);}

	public void testReadReverse () {
        final Scanner r   = new Scanner("99999 5\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b    == true);
        Assert.assertTrue(a[0] ==	99999);
        Assert.assertTrue(a[1] ==   5);}

    // ----
    // eval
    // ----

    public void testEvalSample1 () {
        final int v = Collatz.eval(1, 10);
        Assert.assertTrue(v == 20);}

    public void testEvalSample2 () {
        final int v = Collatz.eval(100, 200);
        Assert.assertTrue(v == 125);}

    public void testEvalSample3 () {
        final int v = Collatz.eval(201, 210);
        Assert.assertTrue(v == 89);}

	public void testEvalSameLow () {
        final int v = Collatz.eval(1, 1);
    	Assert.assertTrue(v == 1);}

	public void testEvalSameMed () {
        final int v = Collatz.eval(8192, 8192);
        Assert.assertTrue(v == 14);}

	public void testEvalSameHigh () {
        final int v = Collatz.eval(65536, 65536);
    	Assert.assertTrue(v == 17);}        
    
    public void testEvalEdgeLow () {
        final int v = Collatz.eval(1, 2);
    	Assert.assertTrue(v == 2);}
    
    public void testEvalEdgeReverse () {
        final int v = Collatz.eval(2, 1);
    	Assert.assertTrue(v == 2);}
    
    public void testEvalEdgeReverse2 () {
        final int v = Collatz.eval(3, 1);
    	Assert.assertTrue(v == 8);}
    
    public void testEvalPowerOfTwoLow () {
        final int v = Collatz.eval(64, 64);
    	Assert.assertTrue(v == 7);}

	public void testEvalPowerOfTwoMed () {
        final int v = Collatz.eval(1024, 1024);
    	Assert.assertTrue(v == 11);}
    
    public void testEvalSampleReverse1 () {
        final int v = Collatz.eval(10, 1);
    	Assert.assertTrue(v == 20);}

    public void testEvalSampleReverse2 () {
        final int v = Collatz.eval(200, 100);
    	Assert.assertTrue(v == 125);}

    public void testEvalSampleReverse3 () {
        final int v = Collatz.eval(210, 201);
    	Assert.assertTrue(v == 89);}

    public void testEval1SampleReverse4 () {
        final int v = Collatz.eval(1000, 900);
    	Assert.assertTrue(v == 174);}

	// ----
	// calculateMax
	// ----

	public void testCalculateMaxSameLow () {
        final int v = Collatz.eval(1, 1);
    	Assert.assertTrue(v == 1);}

	public void testCalculateMaxSameMed () {
        final int v = Collatz.eval(8192, 8192);
        Assert.assertTrue(v == 14);}

	public void testCalculateMaxSameHigh () {
        final int v = Collatz.eval(65536, 65536);
    	Assert.assertTrue(v == 17);}        
    
    public void testCalculateMaxEdgeLow () {
        final int v = Collatz.eval(1, 2);
    	Assert.assertTrue(v == 2);}
    
    public void testCalculateMaxEdgeReverse () {
        final int v = Collatz.eval(99999, 1);
    	Assert.assertTrue(v == 351);}
    
    public void testCalculateMaxEdgeReverse2 () {
        final int v = Collatz.eval(10, 1);
    	Assert.assertTrue(v == 20);}
	
	// ----
    // getCycleLength
    // ----
    
    public void testGetCycleLengthEdgeLow () {
        final int v = Collatz.getCycleLength(1);
    	Assert.assertTrue(v == 1);}
    
    public void testGetCycleLengthPowerOfTwoLow () {
        final int v = Collatz.getCycleLength(2);
    	Assert.assertTrue(v == 2);}
    
    public void testGetCycleLengthLow () {
        final int v = Collatz.getCycleLength(3);
    	Assert.assertTrue(v == 8);}
    
    public void testGetCycleLengthCached () {
        final int v = Collatz.getCycleLength(4);
    	Assert.assertTrue(v == 3);}
    
    public void testGetCycleLengthLow2 () {
        final int v = Collatz.getCycleLength(5);
    	Assert.assertTrue(v == 6);}
    
    public void testGetCycleLengthLow3 () {
        final int v = Collatz.getCycleLength(10);
    	Assert.assertTrue(v == 7);}
    
    public void testGetCycleLengthPowerOfTwoMed () {
        final int v = Collatz.getCycleLength(2048);
    	Assert.assertTrue(v == 12);}
    
    public void testGetCycleLengthPowerOfTwoHigh () {
        final int v = Collatz.getCycleLength(65536);
    	Assert.assertTrue(v == 17);}
    
    // -----
    // print
    // -----

    public void testPrintSample1 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
        Assert.assertTrue(w.toString().equals("1 10 20\n"));}

	public void testPrintSample2 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 100, 200, 125);
        Assert.assertTrue(w.toString().equals("100 200 125\n"));}

	public void testPrintSample3 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 201, 210, 89);
        Assert.assertTrue(w.toString().equals("201 210 89\n"));}

    // -----
    // solve
    // -----

    public void testSolveSample () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
        Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}

	public void testSolveLow () throws IOException {
        final Scanner r = new Scanner("2 2\n3 4\n4 3\n16 16\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
        Assert.assertTrue(w.toString().equals("2 2 2\n3 4 8\n4 3 8\n16 16 5\n"));}

	public void testSolveHigh () throws IOException {
        final Scanner r = new Scanner("1 99999\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
        Assert.assertTrue(w.toString().equals("1 99999 351\n"));}

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
