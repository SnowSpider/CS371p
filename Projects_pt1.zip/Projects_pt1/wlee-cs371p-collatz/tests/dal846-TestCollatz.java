// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
    	
    // ---------------
    // findCycleLength
    // ---------------
    public void testFindCycleLengthCalcMinCycle ()
    {
        final int a = Collatz.findCycleLength(1);
        Assert.assertTrue(a == 1);
    }
    public void testFindCycleLengthCalcSmallCycle ()
    {
        final int a = Collatz.findCycleLength(10);
        Assert.assertTrue(a == 7);
    }
    public void testFindCycleLengthCalcMediumCycle ()
    {
        final int a = Collatz.findCycleLength(1000000);
        Assert.assertTrue(a == 153);
    }
    
    // ------------
    // preloadCache
    // ------------
    public void testPreloadCacheZeroFilled()
    {
        int[] test = new int[Collatz.ARRAY_CACHE_SIZE];
        Collatz.preloadCache (test);
        for (int q = 2; q < 200000 ; ++q)
            Assert.assertTrue(test[q] == 0);
    }
    
    public void testPreloadCacheBigNumsFilled()
    {
        int[] test = new int[Collatz.ARRAY_CACHE_SIZE];
        Collatz.preloadCache (test);
        Assert.assertTrue(test[837799] == 525);
        Assert.assertTrue(test[845223] == 401);
        Assert.assertTrue(test[847358] == 419);
        Assert.assertTrue(test[847359] == 419);
        Assert.assertTrue(test[854191] == 419);
        Assert.assertTrue(test[871915] == 432);
        Assert.assertTrue(test[875681] == 432);
        Assert.assertTrue(test[877398] == 401);
        Assert.assertTrue(test[877399] == 401);
        Assert.assertTrue(test[886855] == 401);
        Assert.assertTrue(test[886953] == 445);
        Assert.assertTrue(test[887975] == 401);
        Assert.assertTrue(test[900735] == 401);
        Assert.assertTrue(test[901991] == 401);
        Assert.assertTrue(test[906175] == 445);
        Assert.assertTrue(test[910107] == 476);
        Assert.assertTrue(test[912167] == 401);
        Assert.assertTrue(test[934299] == 414);
        Assert.assertTrue(test[935478] == 414);
        Assert.assertTrue(test[935479] == 414);
        Assert.assertTrue(test[938143] == 445);
        Assert.assertTrue(test[939497] == 507);
        Assert.assertTrue(test[950943] == 414);
        Assert.assertTrue(test[952479] == 414);
        Assert.assertTrue(test[953279] == 414);
        Assert.assertTrue(test[960962] == 414);
        Assert.assertTrue(test[960963] == 414);
        Assert.assertTrue(test[963113] == 414);
        Assert.assertTrue(test[970599] == 458);
        Assert.assertTrue(test[980905] == 427);
        Assert.assertTrue(test[985142] == 427);
        Assert.assertTrue(test[985143] == 427);
        Assert.assertTrue(test[997823] == 440);
    }
    
    public void testPreloadCache3()
    {
        int[] test = new int[Collatz.ARRAY_CACHE_SIZE];
        Collatz.preloadCache (test);
        Assert.assertTrue(test[1] == 1);
    }
    
    // -------------
    // cacheArrCycle
    // -------------
    public void testCacheArrCycleCalcMinCycle ()
    {
        Collatz.gArray[1] = 1;
        int c = Collatz.cacheArrCycle(1);
        Assert.assertTrue(c == 1);
    }
    public void testCacheArrCycleCalcSmallCycle ()
    {
        Collatz.gArray[1] = 1;
        int c = Collatz.cacheArrCycle(4);
        Assert.assertTrue(c == 3);
    }
    public void testCacheArrCycleCalcLargeCycle ()
    {
        Collatz.gArray[1] = 1;
        int c = Collatz.cacheArrCycle(997823);
        Assert.assertTrue(c == 440);
    }
    public void testCacheArrCycleCalcMaxCycle ()
    {
        Collatz.gArray[1] = 1;
        int c = Collatz.cacheArrCycle(837799);
        Assert.assertTrue(c == 525);
    }

    // ----
    // eval
    // ----

    public void testEval1 () {
        Collatz.preloadCache(Collatz.gArray);
        final int v = Collatz.eval(1, 10);
        
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        Collatz.preloadCache(Collatz.gArray);
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        Collatz.preloadCache(Collatz.gArray);
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        Collatz.preloadCache(Collatz.gArray);
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}

    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
