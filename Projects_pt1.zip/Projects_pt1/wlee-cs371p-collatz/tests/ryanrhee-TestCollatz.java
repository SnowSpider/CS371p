// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);
	}
    
    public void testRead2 () {
        final Scanner r   = new Scanner("2 3\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    2);
    	Assert.assertTrue(a[1] ==   3);
	}
    
    public void testRead3 () {
        final Scanner r   = new Scanner("4 5\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    4);
    	Assert.assertTrue(a[1] ==   5);
	}

    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertEquals(20, v);
	}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertEquals(125, v);
	}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertEquals(89, v);
	}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertEquals(174, v);
    }
    
    public void testEval5 () {
        final int v = Collatz.eval(10, 1);
    	Assert.assertEquals(20, v);
	}

    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));
	}
    
    public void testPrint2 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 2, 3, 4);
    	Assert.assertTrue(w.toString().equals("2 3 4\n"));
	}
    
    public void testPrint3 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 5, 6, 789);
    	Assert.assertTrue(w.toString().equals("5 6 789\n"));
	}

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));
	}
    
    public void testSolve2 () throws IOException {
        final Scanner r = new Scanner("84528 3792\n81921 30146\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("84528 3792 351\n81921 30146 351\n"));
	}
    
    public void testSolve3 () throws IOException {
        final Scanner r = new Scanner("72952 21067\n54437 55769\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("72952 21067 340\n54437 55769 260\n"));
	}
    
    
    public void testCollatz() {
    	Assert.assertEquals(3, Collatz.cl(4));
    }
    
    public void testCollatz2() {
    	Assert.assertEquals(6, Collatz.cl(5));
    }
    
    public void testCollatz3() {
    	Assert.assertEquals(94, Collatz.cl(8654256));
    }
    
    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");
    }
}
