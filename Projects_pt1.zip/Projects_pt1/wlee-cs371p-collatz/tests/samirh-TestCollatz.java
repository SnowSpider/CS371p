// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {

	// ----
    // getId
    // ----
	
	public void testGetId () {
        final Collatz.Pair r   =  new Collatz.Pair(1,10);
    	Assert.assertTrue(r.getId() ==    1);
	}
	
	public void testGetId2 () {
        final Collatz.Pair r   =  new Collatz.Pair(Long.MAX_VALUE,Integer.MAX_VALUE);
    	Assert.assertTrue(r.getId() ==    Long.MAX_VALUE);
	}
	
	public void testGetId3 () {
        final Collatz.Pair r   =  new Collatz.Pair(0,0);
    	Assert.assertTrue(r.getId() ==    0);
	}
	
	// ----
    // getValue
    // ----
	
	public void testGetValue () {
        final Collatz.Pair r   =  new Collatz.Pair(1,10);
    	Assert.assertTrue(r.getValue() ==    10);
	}
	
	public void testGetValue2 () {
        final Collatz.Pair r   =  new Collatz.Pair(Long.MAX_VALUE,Integer.MAX_VALUE);
    	Assert.assertTrue(r.getValue() ==    Integer.MAX_VALUE);
	}
	
	public void testGetValue3 () {
        final Collatz.Pair r   =  new Collatz.Pair(0,0);
    	Assert.assertTrue(r.getValue() ==    0);
	}
	
	// ----
    // setId
    // ----
	
	public void testSetId () {
        final Collatz.Pair r   =  new Collatz.Pair(1,10);
    	Assert.assertTrue(r.getId() ==    1);
		r.setId(1000);
		Assert.assertTrue(r.getId() ==    1000);
		
	}
	
	public void testSetId2 () {
        final Collatz.Pair r   =  new Collatz.Pair(Long.MAX_VALUE,Integer.MAX_VALUE);
    	Assert.assertTrue(r.getId() ==    Long.MAX_VALUE);
		r.setId(2123312);
		Assert.assertTrue(r.getId() ==    2123312);
	}
	
	public void testSetId3 () {
        final Collatz.Pair r   =  new Collatz.Pair(0,0);
    	Assert.assertTrue(r.getId() ==    0);
		r.setId(123456);
		Assert.assertTrue(r.getId() ==    123456);
	}
	
	// ----
    // setValue
    // ----
	
	public void testSetValue () {
        final Collatz.Pair r   =  new Collatz.Pair(1,10);
    	Assert.assertTrue(r.getValue() ==    10);
		r.setValue(86753);
		Assert.assertTrue(r.getValue() ==    86753);
		
	}
	
	public void testSetValue2 () {
        final Collatz.Pair r   =  new Collatz.Pair(Long.MAX_VALUE,Integer.MAX_VALUE);
    	Assert.assertTrue(r.getValue() ==    Integer.MAX_VALUE);
		r.setValue(22222);
		Assert.assertTrue(r.getValue() ==    22222);
	}
	
	public void testSetValue3 () {
        final Collatz.Pair r   =  new Collatz.Pair(0,0);
    	Assert.assertTrue(r.getValue() ==    0);
		r.setValue(Integer.MAX_VALUE);
		Assert.assertTrue(r.getValue() ==    Integer.MAX_VALUE);
	}
	
	// ----
    //  newPair
    // ----
	
	public void testNewPair () {
        final Collatz.Pair r   = Collatz.Pair.newPair(1,10);
    	Assert.assertTrue(r.getId() ==    1);
    	Assert.assertTrue(r.getValue() ==   10);
	}
	
	public void testNewPair2 () {
        final Collatz.Pair r   = Collatz.Pair.newPair(Long.MAX_VALUE,Integer.MAX_VALUE);
    	Assert.assertTrue(r.getId() ==    Long.MAX_VALUE);
    	Assert.assertTrue(r.getValue() ==   Integer.MAX_VALUE);
	}
	
	public void testNewPair3 () {
        final Collatz.Pair r   = Collatz.Pair.newPair(0,0);
    	Assert.assertTrue(r.getId() ==    0);
    	Assert.assertTrue(r.getValue() ==   0);
	}
	
	
	// ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
	
	 public void testReadWhiteSpace () {
	    final Scanner r   = new Scanner("1\t\t   10\n");
	    final int     a[] = {0, 0};
	    final boolean b   = Collatz.read(r, a);
	   	Assert.assertTrue(b    == true);
	    Assert.assertTrue(a[0] ==    1);
	    Assert.assertTrue(a[1] ==   10);}
	
	 public void testReadMultipleDigits () {
	    final Scanner r   = new Scanner("999999 123456\n");
	    final int     a[] = {0, 0};
	    final boolean b   = Collatz.read(r, a);
	   	Assert.assertTrue(b    == true);
	   	Assert.assertTrue(a[0] ==    999999);
	    Assert.assertTrue(a[1] ==   123456);}
	
	 public void testReadCompleteRange () {
	    final Scanner r   = new Scanner("1 1000000\n");
	    final int     a[] = {0, 0};
	    final boolean b   = Collatz.read(r, a);
	   	Assert.assertTrue(b    == true);
	   	Assert.assertTrue(a[0] ==    1);
	    Assert.assertTrue(a[1] ==   1000000);}
    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}

	public void testEval5 () {
	    final int v = Collatz.eval(30, 30);
	    Assert.assertTrue(v == 19);}
	
	public void testEval6 () {
	    final int v = Collatz.eval(10000, 14000);
	    Assert.assertTrue(v == 276);}
	
	public void testEval7 () {
		final int v = Collatz.eval(999900, 1000000);
		Assert.assertTrue(v == 259);}
		
	public void testEval8 () {
		final int v = Collatz.eval(1, 200000);
		Assert.assertTrue(v == 383);}
	
	public void testEval9 () {
		final int v = Collatz.eval(1, 1000000);
		Assert.assertTrue(v == 525);}
	
	// -----
    // cycleLength
    // -----
	
	public void testCycleLength(){
		final int v = Collatz.cycleLength(1000000l);
		Assert.assertTrue(v == 153);}
	
	public void testCycleLength2(){
		final int v = Collatz.cycleLength(123456l);
		Assert.assertTrue(v == 62);} 
	
	public void testCycleLength3(){
		final int v = Collatz.cycleLength(10l);
		Assert.assertTrue(v == 7);}

    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
	
	public void testPrint2 () throws IOException {
	    final Writer w = new StringWriter();
	    Collatz.print(w, 100, 200, 125);
	  	Assert.assertTrue(w.toString().equals("100 200 125\n"));}
	
	public void testPrint3 () throws IOException {
	    final Writer w = new StringWriter();
	    Collatz.print(w, 1, 1000000, 999);
	   	Assert.assertTrue(w.toString().equals("1 1000000 999\n"));}
	public void testPrint4 () throws IOException {
		final Writer w = new StringWriter();
		Collatz.print(w, 123, 456, 7890);
		Assert.assertTrue(w.toString().equals("123 456 7890\n"));}

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
	
	 public void testSolve2 () throws IOException {
	        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n1 10\n100 200\n201 210\n900 1000\n");
	        final Writer  w = new StringWriter();
	        Collatz.solve(r, w);
	    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
	
	public void testSolve3 () throws IOException {
		    final Scanner r = new Scanner("10000 12000\n20000 24000\n30000 35000\n");
		   	final Writer  w = new StringWriter();
		    Collatz.solve(r, w);
		   	Assert.assertTrue(w.toString().equals("10000 12000 268\n20000 24000 282\n30000 35000 311\n"));}
	public void testSolve4 () throws IOException {
			final Scanner r = new Scanner("100000 100200\n200000 200400\n300000 300800\n");
			final Writer  w = new StringWriter();
			Collatz.solve(r, w);
			Assert.assertTrue(w.toString().equals("100000 100200 341\n200000 200400 342\n300000 300800 371\n"));}
    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
