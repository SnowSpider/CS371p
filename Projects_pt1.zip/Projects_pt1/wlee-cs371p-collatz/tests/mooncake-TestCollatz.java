// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar (for bash it should be: export CLASSPATH=$CLASSPATH:/usr/share/java/junit4-4.8.1.jar) 
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    //test for normal input
    public void testRead1 () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}

     //test for symbols input
     public void testRead2 () {
        final Scanner r   = new Scanner("\t");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b != true);}
     
     //test for random input
     public void testRead4 () {
        final Scanner r   = new Scanner("b$@");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b != true);}
     
     //test for empty input
     public void testRead5 () {
        final Scanner r   = new Scanner("");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b != true);}
  
     //test for input with more than just white-space between numbers
     public void testRead6 () {
        final Scanner r   = new Scanner("22 \t 48 \t\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b == true);
        Assert.assertTrue(a[0] == 22);
        Assert.assertTrue(a[1] == 48);}


    // ----
    // eval
    // ----

    //test for range with only one number
    public void testEval1 () {
        final int v = Collatz.eval(1, 1);
    	Assert.assertTrue(v == 1);}

    //test for a range of several numbers
    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    //test for a range of big numbers
    public void testEval3 () {
        final int v = Collatz.eval(93196, 360976);
        Assert.assertTrue(v == 443);}
    
    // ----
    // calc
    // ----

    //test normal case
    public void testCalc1 () {
        final int v = Collatz.calc(3);
        Assert.assertTrue(v ==8);}
 
    //test for simple number
    public void testCalc2 () {
        final int v = Collatz.calc(1);
        Assert.assertTrue(v == 1);}

    //test for big number
    public void testCalc3 () {
        final int v = Collatz.calc(999999);
        Assert.assertTrue(v == 259);}
   
    // -----
    // print
    // -----

    //test for normal print
    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}

    public void testPrint2 () throws IOException {                                                                                                   
        final Writer w = new StringWriter();                                                                                                                         
        Collatz.print(w, 900, 1000, 174);                                                                                                                                 
        Assert.assertTrue(w.toString().equals("900 1000 174\n"));}

    public void testPrint3 () throws IOException {                                                                                                                    
        final Writer w = new StringWriter();                                                                                                                         
        Collatz.print(w, 201, 210, 89);                                                                                                                                 
        Assert.assertTrue(w.toString().equals("201 210 89\n"));}

    public void testPrint4 () throws IOException {                                                                                                                    
        final Writer w = new StringWriter();                                                                                                                         
        Collatz.print(w, 210, 201, 89);                                                                                                                                 
        Assert.assertTrue(w.toString().equals("210 201 89\n"));}

    // -----
    // solve
    // -----

    //test for a set of small numbers
    public void testSolve1 () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
   
    //test for a set of slightly bigger numbers, either small or big number put ahead
    public void testSolve2 () throws IOException {
        final Scanner r = new Scanner("927 7817\n9079 4867\n7425 2305\n7004 9573\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
        Assert.assertTrue(w.toString().equals("927 7817 262\n9079 4867 262\n7425 2305 262\n7004 9573 260\n"));}

    //test for a set of very big numbers
    public void testSolve3 () throws IOException {
        final Scanner r = new Scanner("1 200000\n200001 400000\n400001 600000\n600001 800000\n800001 999999\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
        Assert.assertTrue(w.toString().equals("1 200000 383\n200001 400000 443\n400001 600000 470\n600001 800000 509\n800001 999999 525\n"));}

    //double test a random set of very big numbers
    public void testSolve4 () throws IOException {
        final Scanner r = new Scanner("200145 230000\n245067 266287\n274340 302660\n294422 357583\n367489 395554\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
        Assert.assertTrue(w.toString().equals("200145 230000 386\n245067 266287 407\n274340 302660 389\n294422 357583 441\n367489 395554 436\n"));} 
    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
