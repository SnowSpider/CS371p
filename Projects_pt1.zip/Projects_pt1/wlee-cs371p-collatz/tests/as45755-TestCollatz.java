// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
    
    public void testUpperBound() {
        final Scanner r   = new Scanner("999999 999999\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    999999);
    	Assert.assertTrue(a[1] ==   999999);}
    
    
    public void testLowerBound() {
        final Scanner r   = new Scanner("1     2\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   2);}
    
    public void testWholeBound() {
        final Scanner r   = new Scanner("1 999999\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   999999);}
    
    public void testMiddleUpperBound() {
        final Scanner r   = new Scanner("500000 99999\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    500000);
    	Assert.assertTrue(a[1] ==   99999);}
    
    

    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}
    
    public void testEval5 () {
        final int v = Collatz.eval(1, 1);
    	Assert.assertTrue(v == 1);}
    
    public void testEval6 () {
        final int v = Collatz.eval(1, 2);
    	Assert.assertTrue(v == 2);}

    public void testEval7 () {
        final int v = Collatz.eval(1, 3);
    	Assert.assertTrue(v == 8);}
    
    public void testEval8 () {
        final int v = Collatz.eval(1, 999999);
    	Assert.assertTrue(v == 525);}


    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
    
    public void testPrint2 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 100, 200, 125);
    	Assert.assertTrue(w.toString().equals("100 200 125\n"));}
    
    public void testPrint3 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 201, 210, 89);
    	Assert.assertTrue(w.toString().equals("201 210 89\n"));}
    
    public void testPrint4 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 900, 1000, 174);
    	Assert.assertTrue(w.toString().equals("900 1000 174\n"));}
    
    
  
    
    

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}
    
    public void testSolve2 () throws IOException {
        final Scanner r = new Scanner("900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("900 1000 174\n"));}
    
    public void testSolve3 () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n1 1\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n1 1 1\n"));}
    
    public void testSolve4 () throws IOException {
        final Scanner r = new Scanner("1 10\n200 200\n1 3\n1 2\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n200 200 27\n1 3 8\n1 2 2\n"));}
    
    public void testSolve5 () throws IOException {
        final Scanner r = new Scanner("1 2\n2 1\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 2 2\n2 1 2\n"));}
    

    // ----
    // fillCache
    // ----
    
    public void testCache() throws IOException{
    	int[] maxCycle = Collatz.fillCache(1, 1);
    	Assert.assertTrue(maxCycle[0] == 1);
    	
    	
    	
    }
    
    public void testCache2() throws IOException{
    	int[] maxCycle = Collatz.fillCache(1, 2);
    	Assert.assertTrue(maxCycle[0] == 1);
    	Assert.assertTrue(maxCycle[1] == 2);
    	
    }
    
    public void testCache3() throws IOException{
    	int[] maxCycle = Collatz.fillCache(1, 3);
    	Assert.assertTrue(maxCycle[0] == 1);
    	Assert.assertTrue(maxCycle[1] == 2);
    	Assert.assertTrue(maxCycle[2] == 8);
    	
    }
    
    
    
    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
		