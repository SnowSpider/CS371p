// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}

    public void testRead1 () {
        final Scanner r   = new Scanner("100 200\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==   100);
    	Assert.assertTrue(a[1] ==   200);}

    public void testRead2 () {
        final Scanner r   = new Scanner("201 210\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==   201);
    	Assert.assertTrue(a[1] ==   210);}


    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}

    public void testEval5 () {
        final int v = Collatz.eval(1, 999999);
    	Assert.assertTrue(v == 525);}

    public void testEval6 () {
        final int v = Collatz.eval(123, 12345);
    	Assert.assertTrue(v == 268);}

    public void testEval7 () {
        final int v = Collatz.eval(468, 79833);
    	Assert.assertTrue(v == 351);}

    // -----
    // cycleLen
    // -----

    public void testCycle1 () {
        final int v = Collatz.cycleLen(1);
    	Assert.assertTrue(v == 1);}

    public void testCycle2 () {
        final int v = Collatz.cycleLen(999999);
    	Assert.assertTrue(v == 259);}

    public void testCycle3 () {
        final int v = Collatz.cycleLen(5);
    	Assert.assertTrue(v == 6);}

   public void testCycle () throws IOException {
        int i = Collatz.cycleLen(5);
	System.out.println(i);
    	Assert.assertTrue(i==6);
     }	

    public void testCycle4 () throws IOException {
        int i = Collatz.cycleLen(3);
	System.out.println(i);
    	Assert.assertTrue(i==8);
     }	


    // ----
    // evalCached
    // ----

    public void testEvalC1 () {
        final int v = Collatz.evalCached(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEvalC2 () {
        final int v = Collatz.evalCached(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEvalC3 () {
        final int v = Collatz.evalCached(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEvalC4 () {
        final int v = Collatz.evalCached(900, 1000);
    	Assert.assertTrue(v == 174);}

    public void testEvalC5 () {
        final int v = Collatz.evalCached(1, 999999);
    	Assert.assertTrue(v == 525);}

    public void testEvalC6 () {
        final int v = Collatz.evalCached(123, 12345);
    	Assert.assertTrue(v == 268);}

    public void testEvalC7 () {
        final int v = Collatz.evalCached(468, 79833);
    	Assert.assertTrue(v == 351);}
    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}

    public void testPrint1 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 100, 200, 125);
    	Assert.assertTrue(w.toString().equals("100 200 125\n"));}

    public void testPrint2 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 201, 210, 89);
    	Assert.assertTrue(w.toString().equals("201 210 89\n"));}

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}

    public void testSolve1 () throws IOException {
        final Scanner r = new Scanner("20 1000\n99 1\n201 210\n374 78566\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("20 1000 179\n99 1 119\n201 210 89\n374 78566 351\n"));}

    public void testSolve2 () throws IOException {
        final Scanner r = new Scanner("25 52\n117 71111\n201 210\n250 52000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("25 52 112\n117 71111 340\n201 210 89\n250 52000 324\n"));}

  

   

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
