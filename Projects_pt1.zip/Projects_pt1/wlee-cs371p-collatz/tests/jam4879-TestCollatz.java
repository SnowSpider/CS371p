// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead1 () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
    
    public void testRead2() {
        final Scanner r = new Scanner("1  2\n");
        final int a[] = {0, 0};
        final boolean b = Collatz.read(r, a);
        Assert.assertTrue(b);
        Assert.assertTrue(a[0] == 1);
        Assert.assertTrue(a[1] == 2);
      }

      public void testRead3() {
        final Scanner r = new Scanner("2  10\n");
        final int a[] = {0, 0};
        final boolean b = Collatz.read(r, a);
        Assert.assertTrue(b);
        Assert.assertTrue(a[0] == 2);
        Assert.assertTrue(a[1] == 10);
      }
    
    public void testRead4() {
        final Scanner r = new Scanner("1 1");
        final int a[] = {0, 0};
        final boolean b = Collatz.read(r, a);
        Assert.assertTrue(b);
        Assert.assertTrue(a[0] == 1);
        Assert.assertTrue(a[1] == 1);
      }

          public void testRead5() {
        final Scanner r = new Scanner("1 	 7");
        final int a[] = {0, 0};
        final boolean b = Collatz.read(r, a);
        Assert.assertTrue(b);
        Assert.assertTrue(a[0] == 1);
        Assert.assertTrue(a[1] == 7);
      }

     public void testRead6() {
        final Scanner r = new Scanner("4 1");
        final int a[] = {0, 0};
        final boolean b = Collatz.read(r, a);
        Assert.assertTrue(b);
        Assert.assertTrue(a[0] == 4);
        Assert.assertTrue(a[1] == 1);
      }

          public void testRead7() {
        final Scanner r = new Scanner("10 1\r\n");
        final int a[] = {0, 0};
        final boolean b = Collatz.read(r, a);
        Assert.assertTrue(b);
        Assert.assertTrue(a[0] == 10);
        Assert.assertTrue(a[1] == 1);
      }

     public void testReadSymbols () {
        final Scanner r   = new Scanner("*&@");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b != true);}
     
     public void testReadEmpty () {
        final Scanner r   = new Scanner("");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b != true);}


    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}
    
    public void testEval5 () {
        final int v = Collatz.eval(9, 22);
    	Assert.assertTrue(v == 21);}

    public void testEval6 () {
        final int v = Collatz.eval(10, 1);
    	Assert.assertTrue(v == 20);}

    public void testEval7 () {
        final int v = Collatz.eval(4, 9);
    	Assert.assertTrue(v == 20);}

    public void testEval8 () {
        final int v = Collatz.eval(63, 99);
    	Assert.assertTrue(v == 119);}

    
    // -----
    // print
    // -----

    
    
    public void testPrint1() throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
        Assert.assertTrue(w.toString().equals("1 10 20\n"));}

    public void testPrint2() throws IOException {
      final Writer w = new StringWriter();
      Collatz.print(w, 5, 1, 20);
      Assert.assertTrue(w.toString().equals("5 1 20\n"));
    }

    public void testPrint3() throws IOException {
      final Writer w = new StringWriter();
      Collatz.print(w, 1, 1, 2);
      Assert.assertTrue(w.toString().equals("1 1 2\n"));
    }

    public void testPrint4() throws IOException {
      final Writer w = new StringWriter();
      Collatz.print(w, 2, 2, 3);
      Assert.assertTrue(w.toString().equals("2 2 3\n"));
    }

        public void testPrint5() throws IOException {
      final Writer w = new StringWriter();
      Collatz.print(w, 12, 4, 3);
      Assert.assertTrue(w.toString().equals("12 4 3\n"));
    }

        public void testPrint6() throws IOException {
      final Writer w = new StringWriter();
      Collatz.print(w, 1, 22, 3);
      Assert.assertTrue(w.toString().equals("1 22 3\n"));
    }

        public void testPrint7() throws IOException {
      final Writer w = new StringWriter();
      Collatz.print(w, 3, 3, 33);
      Assert.assertTrue(w.toString().equals("3 3 33\n"));
    }

    //---------------
    //calculateCycles
    //---------------

    public void testCyclesSmall () {
        final int v = Collatz.calculateCycles(10);
    	Assert.assertTrue(v == 7);}

    public void testCyclesLarge () {
        final int v = Collatz.calculateCycles(1);
    	Assert.assertTrue(v == 1);}

    public void testCyclesMin () {
        final int v = Collatz.calculateCycles(999999);
    	Assert.assertTrue(v == 259);}

    public void testCyclesMax  () {
        final int v = Collatz.calculateCycles(777777);
    	Assert.assertTrue(v == 155);}


    // -----
    // solve
    // -----

        
        public void testSolve1() throws IOException {
            final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
            final Writer  w = new StringWriter();
            Collatz.solve(r, w);
            Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}

        public void testSolve2() throws IOException {
            final Scanner r = new Scanner("100 200\n201 210\n63 99\n");
            final Writer  w = new StringWriter();
            Collatz.solve(r, w);
            Assert.assertTrue(w.toString().equals("100 200 125\n201 210 89\n63 99 119\n"));}

        public void testSolve3() throws IOException {
            final Scanner r = new Scanner("21 3\n");
            final Writer  w = new StringWriter();
            Collatz.solve(r, w);
            Assert.assertTrue(w.toString().equals("21 3 21\n"));}

        public void testMax() throws IOException {
            final Scanner r = new Scanner("999999 999999\n");
            final Writer  w = new StringWriter();
            Collatz.solve(r, w);
            Assert.assertTrue(w.toString().equals("999999 999999 259\n"));}

            public void testMiddle() throws IOException {
            final Scanner r = new Scanner("499999 500000\n");
            final Writer  w = new StringWriter();
            Collatz.solve(r, w);
            Assert.assertTrue(w.toString().equals("499999 500000 258\n"));}

            public void testMin() throws IOException {
            final Scanner r = new Scanner("1 1\n");
            final Writer  w = new StringWriter();
            Collatz.solve(r, w);
            Assert.assertTrue(w.toString().equals("1 1 1\n"));}

            public void testSolve7() throws IOException {
            final Scanner r = new Scanner("2000 3333\n");
            final Writer  w = new StringWriter();
            Collatz.solve(r, w);
            Assert.assertTrue(w.toString().equals("2000 3333 217\n"));}

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
