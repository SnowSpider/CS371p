// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----
	
    public void testReadBasic1 () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}

    public void testReadBasic2 () {
        final Scanner r   = new Scanner("2000 3000\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b    == true);
        Assert.assertTrue(a[0] == 2000);
        Assert.assertTrue(a[1] == 3000);}

    public void testRead3Args () {
        final Scanner r   = new Scanner("1 2 3\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b    == true);
        Assert.assertTrue(a[0] ==    1);
        Assert.assertTrue(a[1] ==    2);}

    public void testRead1Arg () {
        final Scanner r   = new Scanner("1\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
        Assert.assertTrue(b    == false);
        Assert.assertTrue(a[0] ==    1);
        Assert.assertTrue(a[1] ==    0);}
    
    public void testReadEmptyString(){
    	final Scanner r = new Scanner("");
    	final int a[] = {0, 0};
    	final boolean b = Collatz.read(r,a);
    	Assert.assertTrue(b == false);
    	Assert.assertTrue(a[0] == 0);
    	Assert.assertTrue(a[0] == 0);
    }


    // ----
    // eval
    // ---- 
    
    public void testEvalBasic1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEvalBasic2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEvalBasic3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEvalBasic4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}
    	
    public void testEvalOverflowTest(){
    	final int v = Collatz.eval(999512, 999913);
    	Assert.assertTrue(v == 290);}

    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
    
    public void testPrint2() throws IOException{
    	final Writer w = new StringWriter();
    	Collatz.print(w, 999999, 999999, 999999);
    	Assert.assertTrue(w.toString().equals("999999 999999 999999\n"));
    }
    
    public void testPrint3() throws IOException{
    	final Writer w = new StringWriter();
    	Collatz.print(w, 12345, 54321, 12345);
    	Assert.assertTrue(w.toString().equals("12345 54321 12345\n"));
    }
    
    public void testPrintWriterNull() throws IOException{
    	final Writer w = null;
    	try{
    		Collatz.print(w, 1, 1, 1);
    		fail();
    	} catch(IOException ioe){
    		Assert.assertNotNull(ioe);
    	};
    }

    // -----
    // solve
    // -----

    public void testSolveBasic1 () throws IOException {
        final Scanner r = new Scanner("1 10\n" +
        		                      "100 200\n" +
        		                      "201 210\n" +
        		                      "900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals(     "1 10 20\n" +
    			                               "100 200 125\n" +
    			                                "201 210 89\n" +
    			                              "900 1000 174\n"));}
    
    public void testSolveBasic2 () throws IOException {
        final Scanner r = new Scanner("906541 503355\n" +
                					  "904314 131353\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("906541 503355 525\n" +
    			                              "904314 131353 525\n"));}
    
    public void testSolveBasic3 () throws IOException {
        final Scanner r = new Scanner("184 577\n" +
                                      "659 186\n" +
                                       "71 205\n" +
                                       "61 325\n" + 
                                       "27 156\n" +
                                      "453 481\n" );
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("184 577 144\n" +
    			                              "659 186 145\n" +
    			                               "71 205 125\n" +
    			                               "61 325 131\n" +
    			                               "27 156 122\n" +
    			                              "453 481 129\n"));}
    
    public void TestSolveWhitespace() throws IOException{
    	final Scanner r = new Scanner("184 577\n\n659 186");
    	final Writer w = new StringWriter();
    	Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("184 577 144\n"));
    }
   
    
    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
