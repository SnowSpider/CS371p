// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % setenv CLASSPATH .:/share/opt/junit-4.5/junit-4.5.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead1 () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}

    public void testRead2() {
      final Scanner r = new Scanner("1  10\n");
      final int a[] = {0, 0};
      final boolean b = Collatz.read(r, a);
      Assert.assertTrue(b);
      Assert.assertTrue(a[0] == 1);
      Assert.assertTrue(a[1] == 10);
    }

    public void testRead3() {
      final Scanner r = new Scanner("1       10\n");
      final int a[] = {0, 0};
      final boolean b = Collatz.read(r, a);
      Assert.assertTrue(b);
      Assert.assertTrue(a[0] == 1);
      Assert.assertTrue(a[1] == 10);
    }

    public void testRead4() {
      final Scanner r = new Scanner("10 1");
      final int a[] = {0, 0};
      final boolean b = Collatz.read(r, a);
      Assert.assertTrue(b);
      Assert.assertTrue(a[0] == 10);
      Assert.assertTrue(a[1] == 1);
    }

	public void testRead5() {
      final Scanner r = new Scanner("13 \t 3");
      final int a[] = {0, 0};
      final boolean b = Collatz.read(r, a);
      Assert.assertTrue(b);
      Assert.assertTrue(a[0] == 13);
      Assert.assertTrue(a[1] == 3);
    }

	public void testRead6() {
      final Scanner r = new Scanner("105 51");
      final int a[] = {0, 0};
      final boolean b = Collatz.read(r, a);
      Assert.assertTrue(b);
      Assert.assertTrue(a[0] == 105);
      Assert.assertTrue(a[1] == 51);
    }

	public void testRead7() {
      final Scanner r = new Scanner("10 1\r\n");
      final int a[] = {0, 0};
      final boolean b = Collatz.read(r, a);
      Assert.assertTrue(b);
      Assert.assertTrue(a[0] == 10);
      Assert.assertTrue(a[1] == 1);
    }

    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}
	
	public void testEval5 () {
        final int v = Collatz.eval(2504, 2511);
    	Assert.assertTrue(v == 134);}

	public void testEval6 () {
        final int v = Collatz.eval(3121, 3206);
    	Assert.assertTrue(v == 199);}

	public void testEval7 () {
        final int v = Collatz.eval(502441, 502441);
    	Assert.assertTrue(v == 333);}

    // -----
    // print
    // -----

    public void testPrint1() throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}

    public void testPrint2() throws IOException {
      final Writer w = new StringWriter();
      Collatz.print(w, 10, 1, 20);
      Assert.assertTrue(w.toString().equals("10 1 20\n"));
    }

    public void testPrint3() throws IOException {
      final Writer w = new StringWriter();
      Collatz.print(w, 1, 1, 1);
      Assert.assertTrue(w.toString().equals("1 1 1\n"));
    }

    public void testPrint4() throws IOException {
      final Writer w = new StringWriter();
      Collatz.print(w, 1, 2, 3);
      Assert.assertTrue(w.toString().equals("1 2 3\n"));
    }

	public void testPrint5() throws IOException {
      final Writer w = new StringWriter();
      Collatz.print(w, 1, 24, 3);
      Assert.assertTrue(w.toString().equals("1 24 3\n"));
    }

	public void testPrint6() throws IOException {
      final Writer w = new StringWriter();
      Collatz.print(w, 1, 2, 63);
      Assert.assertTrue(w.toString().equals("1 2 63\n"));
    }

	public void testPrint7() throws IOException {
      final Writer w = new StringWriter();
      Collatz.print(w, 13, 23, 33);
      Assert.assertTrue(w.toString().equals("13 23 33\n"));
    }

    // -----
    // solve
    // -----

    public void testSolve1() throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}

    public void testSolve2() throws IOException {
        final Scanner r = new Scanner("1 1\n2 2\n  3  3\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 1 1\n2 2 2\n3 3 8\n"));}

    public void testSolve3() throws IOException {
        final Scanner r = new Scanner("2370 23043\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("2370 23043 279\n"));}

    public void testSolve4() throws IOException {
        final Scanner r = new Scanner("2518 1007\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("2518 1007 209\n"));}

	public void testSolve5() throws IOException {
        final Scanner r = new Scanner("502441 502441\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("502441 502441 333\n"));}

	public void testSolve6() throws IOException {
        final Scanner r = new Scanner("1 1\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 1 1\n"));}

	public void testSolve7() throws IOException {
        final Scanner r = new Scanner("2197 2250\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("2197 2250 183\n"));}

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
