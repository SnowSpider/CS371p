// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
    // ----
    // read
    // ----

    public void testRead1 () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}

    public void testRead_largeNums () {
        final Scanner r   = new Scanner("900000 999999\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==   900000);
    	Assert.assertTrue(a[1] ==   999999);}

    public void testRead_mediumNums () {
        final Scanner r   = new Scanner("600 7890\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==   600);
    	Assert.assertTrue(a[1] ==   7890);}

    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}

    public void testEval_intOverflow () {
        final int v = Collatz.eval(113383, 134379);
    	Assert.assertTrue(v == 349);}

    public void testEval_longOverflow () {
        final int v = Collatz.eval(997823, 997824);
    	Assert.assertTrue(v == 174);}

    public void testEval_singleNumber () {
        final int v = Collatz.eval(400, 400);
    	Assert.assertTrue(v == 28);}

    public void testEval_entireRange () {
        final int v = Collatz.eval(1, 999999);
    	Assert.assertTrue(v == 525);}

    // -----
    // print
    // -----

    public void testPrint1 () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}

    public void testPrint_bigInput () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 113383, 134379, 349);
    	Assert.assertTrue(w.toString().equals("113383 134379 349\n"));}

    public void testPrint_allOnes () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 1, 1);
    	Assert.assertTrue(w.toString().equals("1 1 1\n"));}

    public void testPrint_averageInput () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 400, 400, 28);
    	Assert.assertTrue(w.toString().equals("400 400 28\n"));}

    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 1\n1 1\n1 1\n1 1\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 1 1\n1 1 1\n1 1 1\n1 1 1\n"));}

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("50 20\n20 50\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("50 20 112\n20 50 112\n"));}

    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
