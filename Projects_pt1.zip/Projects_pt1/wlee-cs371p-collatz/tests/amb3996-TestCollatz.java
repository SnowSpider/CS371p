// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------

/*
To test the program:
    % locate junit4-4.8
    /usr/share/java/junit4-4.8.1.jar
    % setenv CLASSPATH .:/usr/share/java/junit4-4.8.1.jar
    % javac -Xlint TestCollatz.java
    % java  -ea    TestCollatz > TestCollatz.java.out
*/

// -------
// imports
// -------

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;


import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
	
    // ----
    // read
    // ----

    public void testRead () {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
    
    // ----
    // my read testcases
    // ----
    
    //ensures it can read multiple lines
    public void testReadMultipleLines () {
    	final Scanner r   = new Scanner("1 10\n2 7\n10000 80000\n");
    	final int     a[] = {0, 0};
    	final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);
    	final int     c[] = {0, 0};
    	final boolean d   = Collatz.read(r, c);
    	Assert.assertTrue(d    == true);
    	Assert.assertTrue(c[0] ==   2);
    	Assert.assertTrue(c[1] ==   7);
    	final int     e[] = {0, 0};
    	final boolean f   = Collatz.read(r, e);
    	Assert.assertTrue(f    == true);
    	Assert.assertTrue(e[0] ==    10000);
    	Assert.assertTrue(e[1] ==   80000);}

    //ensures that when there is nothing left to read, read returns false and the values in 
    // a[] are not modified 
    public void testReadReturnsFalseIfScannerIsEmpty() {
        final Scanner r   = new Scanner("1 10\n");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == true);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);
    	final boolean c = Collatz.read(r, a);
    	Assert.assertTrue(c == false);
    	Assert.assertTrue(a[0] ==    1);
    	Assert.assertTrue(a[1] ==   10);}
    
    //checks that when there is no input in the scanner, read can successfully return false.
    public void testReadNoInput () {
        final Scanner r   = new Scanner("");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == false);
    	Assert.assertTrue(a[0] ==    0);
    	Assert.assertTrue(a[1] ==    0);}
    
  //checks that when the scanner is given text instead of numbers, read can successfully return false.
    public void testReadNonIntInput () {
        final Scanner r   = new Scanner("one two");
        final int     a[] = {0, 0};
        final boolean b   = Collatz.read(r, a);
    	Assert.assertTrue(b    == false);
    	Assert.assertTrue(a[0] ==    0);
    	Assert.assertTrue(a[1] ==    0);}
    
    // ----
    // eval
    // ----

    public void testEval1 () {
        final int v = Collatz.eval(1, 10);
    	Assert.assertTrue(v == 20);}

    public void testEval2 () {
        final int v = Collatz.eval(100, 200);
    	Assert.assertTrue(v == 125);}

    public void testEval3 () {
        final int v = Collatz.eval(201, 210);
    	Assert.assertTrue(v == 89);}

    public void testEval4 () {
        final int v = Collatz.eval(900, 1000);
    	Assert.assertTrue(v == 174);}
    
    // ----
    // my eval tests
    // ----
    
    //tests over range [1,1]
    public void testEvalBottomEdge () {
        final int v = Collatz.eval(1, 1);
    	Assert.assertTrue(v == 1);}
    
    //tests over entire range of values the program accepts
    public void testEvalTopEdge () {
        final int v = Collatz.eval(999000, 1000000);
    	Assert.assertTrue(v == 396);} //fix this value

    //tests range of 2 numbers, in which the cycle length of the smaller number is larger
    //than the cycle length of the larger number
    public void testEvalRange3To4 () {
        final int v = Collatz.eval(3, 4);
    	Assert.assertTrue(v == 8);}
    
    // -----
    // cycle_length
    // -----

    //test on smallest number permitted
    public void testCycle_LengthOf1 () {
        final int v = Collatz.cycle_length(1);
    	Assert.assertTrue(v == 1);}
    
    //test on largest number permitted 
    public void testCycle_LengthOf1Million () {
        final int v = Collatz.cycle_length(1000000);
    	Assert.assertTrue(v == 153);}  
    
    //tests an odd number
    public void testCycle_LengthOf77 () {
        final int v = Collatz.cycle_length(77);
    	Assert.assertTrue(v == 23);} //fix this value
    
    //tests 2's cycle length
    public void testCycle_LengthOf2 () {
        final int v = Collatz.cycle_length(2);
    	Assert.assertTrue(v == 2);}
    
    // -----
    // print
    // -----

    public void testPrint () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n"));}
    
    // -----
    // my print tests
    // -----

    //tests printing multiple lines
    public void testPrintMultipleLines () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
        Collatz.print(w, 1, 10, 20);
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(w.toString().equals("1 10 20\n1 10 20\n1 10 20\n"));} //this might be "1 10 20\n" b/c of flush - verify
    
    //confirm that even if an assertion within print fails it will print the result
    public void testPrintIncludesLastEndline () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1, 10, 20);
    	Assert.assertTrue(!w.toString().equals("1 10 20"));}
    
    //tests printing large numbers
    public void testPrintLargeNumbers () throws IOException {
        final Writer w = new StringWriter();
        Collatz.print(w, 1000, 1000000, 202); //not accurate results 
    	Assert.assertTrue(w.toString().equals("1000 1000000 202\n"));}
  
    
    
    // -----
    // solve
    // -----

    public void testSolve () throws IOException {
        final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));}

    // -----
    // my solve tests
    // -----

    public void testSolveAListOfNumbers () throws IOException {
        final Scanner r = new Scanner("6 90\n60 620\n450 610\n20000 25000\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("6 90 116\n60 620 144\n450 610 142\n20000 25000 282\n"));}
    
    public void testSolveAnotherListOfNumbers () throws IOException {
        final Scanner r = new Scanner("1 2\n999999 1000000\n333 555\n6000 9870\n");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals("1 2 2\n999999 1000000 259\n333 555 142\n6000 9870 262\n"));}
    
    public void testSolveEmptyInput () throws IOException {
        final Scanner r = new Scanner("");
        final Writer  w = new StringWriter();
        Collatz.solve(r, w);
    	Assert.assertTrue(w.toString().equals(""));}
    
    // ----
    // main
    // ----

    public static void main (String[] args) {
        System.out.println("TestCollatz.java");
        TestRunner.run(new TestSuite(TestCollatz.class));
        System.out.println("Done.");}}
