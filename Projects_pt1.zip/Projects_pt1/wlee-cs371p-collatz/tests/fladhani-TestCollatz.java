// ---------------------------------
// projects/collatz/TestCollatz.java
// Copyright (C) 2011
// Glenn P. Downing
// ---------------------------------
// Fahad Ladhani
// ---------------------------------

/*
 To test the program:
 % locate junit4-4.8
 /usr/share/java/junit4-4.8.1.jar
 % export CLASSPATH=.:/usr/share/java/junit4-4.8.1.jar (CS UNIX)
 % export CLASSPATH=.:/usr/share/java/junit-3.8.2.jar (HOME UNIX)
 % set CLASSPATH=.;C:\junit4.10\junit-4.10.jar (WINDOWS)
 % javac -Xlint TestCollatz.java
 % java  -ea    TestCollatz > TestCollatz.java.out
 */

// -------
// imports
// -------
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import java.util.Scanner;

import junit.framework.Assert;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

// -----------
// TestCollatz
// -----------

public final class TestCollatz extends TestCase {
	// ----
	// read
	// ----

	public void testRead() {
		final Scanner r = new Scanner("1 10\n");
		final int a[] = { 0, 0 };
		final boolean b = Collatz.read(r, a);
		Assert.assertTrue(b == true);
		Assert.assertTrue(a[0] == 1);
		Assert.assertTrue(a[1] == 10);
	}
	
	public void testRead_lowerBound() {
		final Scanner r = new Scanner("1 1\n");
		final int a[] = { 0, 0 };
		final boolean b = Collatz.read(r, a);
		Assert.assertTrue(b == true);
		Assert.assertTrue(a[0] == 1);
		Assert.assertTrue(a[1] == 1);
	}
	
	public void testRead_mid1() {
		final Scanner r = new Scanner("499999 500000\n");
		final int a[] = { 0, 0 };
		final boolean b = Collatz.read(r, a);
		Assert.assertTrue(b == true);
		Assert.assertTrue(a[0] == 499999);
		Assert.assertTrue(a[1] == 500000);
	}
	
	public void testRead_mid2() {
		final Scanner r = new Scanner("500000 499999\n");
		final int a[] = { 0, 0 };
		final boolean b = Collatz.read(r, a);
		Assert.assertTrue(b == true);
		Assert.assertTrue(a[0] == 500000);
		Assert.assertTrue(a[1] == 499999);
	}
	
	public void testRead_upperBound() {
		final Scanner r = new Scanner("999999 999999\n");
		final int a[] = { 0, 0 };
		final boolean b = Collatz.read(r, a);
		Assert.assertTrue(b == true);
		Assert.assertTrue(a[0] == 999999);
		Assert.assertTrue(a[1] == 999999);
	}

	public void testRead_overflow() {
		final Scanner r = new Scanner("459759 459759\n");
		final int a[] = { 0, 0 };
		final boolean b = Collatz.read(r, a);
		Assert.assertTrue(b == true);
		Assert.assertTrue(a[0] == 459759);
		Assert.assertTrue(a[1] == 459759);
	}
	
	public void testRead_noInput() {
		final Scanner r = new Scanner("");
		final int a[] = { 0, 0 };
		final boolean b = Collatz.read(r, a);
		Assert.assertTrue(b == false);
		Assert.assertTrue(a[0] == 0);
		Assert.assertTrue(a[1] == 0);
	}
	
	public void testRead_wrong() {
		final Scanner r = new Scanner("1 1\n");
		final int a[] = { 0, 0 };
		final boolean b = Collatz.read(r, a);
		Assert.assertTrue(b == true);
		Assert.assertFalse(a[0] == 2);
		Assert.assertFalse(a[1] == 2);
	}

	// ----
	// eval
	// ----

	public void testEval1() {
		final int v = Collatz.eval(1, 10);
		Assert.assertTrue(v == 20);
	}

	public void testEval2() {
		final int v = Collatz.eval(100, 200);
		Assert.assertTrue(v == 125);
	}

	public void testEval3() {
		final int v = Collatz.eval(201, 210);
		Assert.assertTrue(v == 89);
	}

	public void testEval4() {
		final int v = Collatz.eval(900, 1000);
		Assert.assertTrue(v == 174);
	}
	
	public void testEval_lowerBound() {
		final int v = Collatz.eval(1, 1);
		Assert.assertTrue(v == 1);
	}
	
	public void testEval_mid1() {
		final int v = Collatz.eval(499999, 500000);
		Assert.assertTrue(v == 258);
	}
	
	public void testEval_mid2() {
		final int v = Collatz.eval(500000, 499999);
		Assert.assertTrue(v == 258);
	}
	
	public void testEval_upperBound() {
		final int v = Collatz.eval(999999, 999999);
		Assert.assertTrue(v == 259);
	}

	public void testEval_overflow() {
		final int v = Collatz.eval(459759, 459759);
		Assert.assertTrue(v == 214);
	}
	
	public void testEval_wrong() {
		final int v = Collatz.eval(1, 1);
		Assert.assertFalse(v == 2);
	}
	
	public void testEval_eval1() {
		final int v = Collatz.eval(1);
		Assert.assertTrue(v == 1);
	}
	
	public void testEval_eval2() {
		final int v = Collatz.eval(2);
		Assert.assertTrue(v == 2);
	}
	
	public void testEval_eval3() {
		final int v = Collatz.eval(3);
		Assert.assertTrue(v == 8);
	}
	
	public void testEval_eval4() {
		final int v = Collatz.eval(4);
		Assert.assertTrue(v == 3);
	}
	
	public void testEval_eval5() {
		final int v = Collatz.eval(5);
		Assert.assertTrue(v == 6);
	}
	
	public void testEval_eval6() {
		final int v = Collatz.eval(6);
		Assert.assertTrue(v == 9);
	}

	public void testEval_overflow2() {
		final int v = Collatz.eval(459759);
		Assert.assertTrue(v == 214);
	}

	// -----
	// print
	// -----

	public void testPrint() throws IOException {
		final Writer w = new StringWriter();
		Collatz.print(w, 1, 10, 20);
		Assert.assertTrue(w.toString().equals("1 10 20\n"));
	}
	
	public void testPrint_lowerBound() throws IOException {
		final Writer w = new StringWriter();
		Collatz.print(w, 1, 1, 1);
		Assert.assertTrue(w.toString().equals("1 1 1\n"));
	}
	
	public void testPrint_mid1() throws IOException {
		final Writer w = new StringWriter();
		Collatz.print(w, 499999, 500000, 258);
		Assert.assertTrue(w.toString().equals("499999 500000 258\n"));
	}
	
	public void testPrint_mid2() throws IOException {
		final Writer w = new StringWriter();
		Collatz.print(w, 500000, 499999, 258);
		Assert.assertTrue(w.toString().equals("500000 499999 258\n"));
	}
	
	public void testPrint_upperbound() throws IOException {
		final Writer w = new StringWriter();
		Collatz.print(w, 999999, 999999, 259);
		Assert.assertTrue(w.toString().equals("999999 999999 259\n"));
	}

	public void testPrint_overflow() throws IOException {
		final Writer w = new StringWriter();
		Collatz.print(w, 459759, 459759, 214);
		Assert.assertTrue(w.toString().equals("459759 459759 214\n"));
	}
	
	public void testPrint_wrong() throws IOException {
		final Writer w = new StringWriter();
		Collatz.print(w, 1, 1, 1);
		Assert.assertFalse(w.toString().equals("1 1 2\n"));
	}

	// -----
	// solve
	// -----

	public void testSolve() throws IOException {
		final Scanner r = new Scanner("1 10\n100 200\n201 210\n900 1000\n");
		final Writer w = new StringWriter();
		Collatz.solve(r, w);
		Assert.assertTrue(w.toString().equals(
				"1 10 20\n100 200 125\n201 210 89\n900 1000 174\n"));
	}
	
	public void testSolve_set1() throws IOException {
		final Scanner r = new Scanner("1 1\n499999 500000\n500000 499999\n999999 999999\n");
		final Writer w = new StringWriter();
		Collatz.solve(r, w);
		Assert.assertTrue(w.toString().equals(
				"1 1 1\n499999 500000 258\n500000 499999 258\n999999 999999 259\n"));
	}
	
	public void testSolve_set2() throws IOException {
		final Scanner r = new Scanner("1 3\n4 4\n3 1\n");
		final Writer w = new StringWriter();
		Collatz.solve(r, w);
		Assert.assertTrue(w.toString().equals(
				"1 3 8\n4 4 3\n3 1 8\n"));
	}
	
	public void testSolve_set3() throws IOException {
		final Scanner r = new Scanner("9 2\n");
		final Writer w = new StringWriter();
		Collatz.solve(r, w);
		Assert.assertTrue(w.toString().equals(
				"9 2 20\n"));
	}

	public void testSolve_overflow() throws IOException {
		final Scanner r = new Scanner("459759 459759\n");
		final Writer w = new StringWriter();
		Collatz.solve(r, w);
		Assert.assertTrue(w.toString().equals(
				"459759 459759 214\n"));
	}
	
	public void testSolve_noInput() throws IOException {
		final Scanner r = new Scanner("");
		final Writer w = new StringWriter();
		Collatz.solve(r, w);
		Assert.assertTrue(w.toString().equals(
				""));
	}
	
	public void testSolve_wrong() throws IOException {
		final Scanner r = new Scanner("9 2\n");
		final Writer w = new StringWriter();
		Collatz.solve(r, w);
		Assert.assertFalse(w.toString().equals(
				"9 2 2\n"));
	}

	// ----
	// main
	// ----

	public static void main(String[] args) {
		System.out.println("TestCollatz.java");
		TestRunner.run(new TestSuite(TestCollatz.class));
		System.out.println("Done.");
	}
}
