// --------------------------------
// Grades
// February 2012
// Author: Wonjun Lee, Alysha Behn
// --------------------------------

/*

To configure Doxygen:
% doxygen -g
That creates the file "Doxyfile".
Make the following edits:
EXTRACT_ALL = YES
EXTRACT_PRIVATE = YES
EXTRACT_STATIC = YES
GENERATE_LATEX = NO

To document the program:
% doxygen Doxyfile

*/

// --------
// includes
// --------

#include <cassert> // assert
#include <iostream> // endl, istream, ostream
#include <string>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <ctime>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <ios>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <map>
#include <stdexcept>

using namespace std;

//#define DOUBLE_max std::numeric_limits<double>::max()

//forward definition of myBoard class

// --------
// creature
// --------

/**
* A chess piece on the board.
*/

struct Creature{
    
    static map< char, vector<string> > dictionary;
        
    char species;
    char direction; // 'N' 'S' 'W' 'E'
    int programCounter;
    vector<string> instructions; //{"hop", "is_empty 5", ...}
    int turn;
    bool hopped;
    
// ---------------
// init_dictionary
// ---------------

/**
* Initialize the dictionary with the basic 5 species.
*/

    void init_dictionary(){
        //food
        vector<string> foodInstructions;
        foodInstructions.push_back("left");
        foodInstructions.push_back("go 0");
        dictionary['f'] = foodInstructions;
        
        //hopper
        vector<string> hopperInstructions;
        hopperInstructions.push_back("hop");
        hopperInstructions.push_back("go 0");
        dictionary['h'] = hopperInstructions;
        
        //rover
        vector<string> roverInstructions;
        roverInstructions.push_back("if_enemy 9");
        roverInstructions.push_back("if_empty 7");
        roverInstructions.push_back("if_random 5");
        roverInstructions.push_back("left");
        roverInstructions.push_back("go 0");
        roverInstructions.push_back("right");
        roverInstructions.push_back("go 0");
        roverInstructions.push_back("hop");
        roverInstructions.push_back("go 0");
        roverInstructions.push_back("infect");
        roverInstructions.push_back("go 0");
        dictionary['r'] = roverInstructions;
            
        //trap
        vector<string> trapInstructions;
        trapInstructions.push_back("if_enemy 3");
        trapInstructions.push_back("left");
        trapInstructions.push_back("go 0");
        trapInstructions.push_back("infect");
        trapInstructions.push_back("go 0");
        dictionary['t'] = trapInstructions;
        
        //best
        vector<string> bestInstructions;
        bestInstructions.push_back("if_enemy 10");
        bestInstructions.push_back("if_wall 4");
        bestInstructions.push_back("if_empty 8");
        bestInstructions.push_back("if_random 6");
        bestInstructions.push_back("left");
        bestInstructions.push_back("go 0");
        bestInstructions.push_back("right");
        bestInstructions.push_back("go 0");
        bestInstructions.push_back("hop");
        bestInstructions.push_back("go 0");
        bestInstructions.push_back("infect");
        bestInstructions.push_back("go 0");
        dictionary['b'] = bestInstructions;
        
    }

// --------
// creature
// --------

/**
* The default constructor of the Creature class.
*/

    Creature(){
        if(dictionary.size() == 0) init_dictionary();
        programCounter = 0;
        turn = 0;
        hopped = false;
    }

// --------
// creature
// --------

/**
* The parametric constructor of the Creature class.
* @param mySpecies the species.
* @param dir the direction to which the creature faces.
*/

    Creature(char mySpecies, char dir){
        if(!(mySpecies == 'f' ||
                mySpecies == 'h' ||
                mySpecies == 'r' ||
                mySpecies == 't' ||
                mySpecies == 'b')){
		throw invalid_argument("invalid argument");
	}
        if(!(dir == 'N' ||
                dir == 'S' ||
                dir == 'E' ||
                dir == 'W')){
		throw invalid_argument("invalid argument");
	}
        if(dictionary.size() == 0) init_dictionary();
        //myBoard& _g, 
        //static myBoard& g = _g;
        species = mySpecies;
        instructions = dictionary[species];
        
        direction = dir;
        programCounter = 0;
        turn = 0;
        hopped = false;
    }

// ------------
// take_bigTurn
// ------------

/**
* Increment the turn variable, which means the creature has executed all the possible instructions in its current turn.
*/

    void take_bigTurn(){
        hopped = true;
        ++turn;
    }
    
    void take_bigTurn_reset(){
        hopped = false;
    }

// ---------
// take_turn
// ---------

/**
* Execute an instruction.
*/

    string take_turn(){
        string instruction = instructions[programCounter++];
        stringstream stream;
        string word;
        stream.clear();
        stream.str(instruction); 
        getline(stream, word, ' ');
        if(word == "left"){
            turnLeft();
	    take_bigTurn();
        }
        else if(word == "right"){
            turnRight();
	    take_bigTurn();
        }
        else if(word == "go"){
            getline(stream, word, ' ');
            int n = atoi(word.c_str());
            assert (n >= 0 && n < (int)instructions.size());
            programCounter = n;
        }
        else if(word == "random"){
            getline(stream, word, ' ');
            int n = atoi(word.c_str());
            int myRand = rand();
            if(myRand % 2 == 1){ // odd -> go to instruction #n
                next_instruction(n);
            }
        }
	return instruction;
    }    

// --------
// turnLeft
// --------

/**
* Rotate the creature by 90 degrees counterclockwise.
*/

    void turnLeft(){ // turn counterclockwise
        assert (direction == 'N' ||
                direction == 'S' ||
                direction == 'E' ||
                direction == 'W');
        if(direction == 'N'){
            direction = 'W';
        }
        else if(direction == 'S'){
            direction = 'E';
        }
        else if(direction == 'W'){
            direction = 'S';
        }
        else if(direction == 'E'){
            direction = 'N';
        }
    }

// ---------
// turnRight
// ---------

/**
* Rotate the creature by 90 degrees clockwise.
*/

    void turnRight(){ // turn clockwise
        assert (direction == 'N' ||
                direction == 'S' ||
                direction == 'E' ||
                direction == 'W');
        if(direction == 'N'){
            direction = 'E';
        }
        else if(direction == 'S'){
            direction = 'W';
        }
        else if(direction == 'W'){
            direction = 'N';
        }
        else if(direction == 'E'){
            direction = 'S';
        }
    }

// -----------
// sameSpecies
// -----------

/**
* Compare the species of two creatures. 
* @param him the other creature.
* @return true if they are of the same species, false otherwise
*/

    bool sameSpecies(Creature& him){
        return (him.species == species);
    }
    
    
// ------
// infect
// ------

/**
* Infect the target creature.
* @param target the target of infection.
*/
    
    void infect(Creature& target){
        target.species = species;
        target.instructions = dictionary[species];
        target.programCounter = 0;
    }

// ----------------
// next_instruction
// ----------------

/**
* Go to the nth instruction.
* @param n the program index.
*/

    void next_instruction(int n){
        assert (n >= 0 && n < (int)instructions.size());
        programCounter = n;
    }
    
};

map<char, vector<string> > Creature::dictionary;

// ----
// Grid
// ----

/**
* The chess board.
*/

struct Grid {
    
    int numColumns;
    int numRows;
    int round;
    
    vector< vector <Creature*> > myBoard;
    
// ----
// Grid
// ----

/**
* The parametric constructor of the Grid class.
* @param r the number of rows.
* @param c the number of columns.
*/
    
    Grid(int r, int c){
        numColumns = c;
        numRows = r;
        Creature* init;
        init = NULL;
        
        for(int i = 0; i < r; i++){
            vector<Creature*> col (c, init);
            myBoard.push_back(col);
        }
        round = 0; 
    }
    
// --------------
// deployCreature
// --------------

/**
* Places a new creature on the board.
* @param newCreature the creature to be deployed.
* @param r the row coordinate.
* @param c the columns coordinate.
*/

    void deployCreature(Creature& newCreature, int r, int c){
        if(!(r < numRows && c < numColumns && r >= 0 && c >= 0)){
		throw out_of_range("out of range");
	}
        myBoard[r][c] = &newCreature;
    }
    
// ----
// turn
// ----

/**
* Take a turn of the game.
*/    
    
    void turn(){
        ++ round;
        
        // scan myBoard
        
        for( int r = 0; r < numRows; r++){
            for(int c = 0; c < numColumns; c++){
                //if(myBoard[r][c] != NULL && round != myBoard[r][c]->turn){
                if(myBoard[r][c] != NULL && !(myBoard[r][c]->hopped)){
                    bool action = false;
                    while(action == false){
                        string instruction = myBoard[r][c]->take_turn();
                        //parse string
                        stringstream stream;
                        string word;
                        stream.clear();
                        stream.str(instruction); 
                        getline(stream, word, ' ');
                        char dir = myBoard[r][c]->direction;
                        
                        if(word == "hop"){ //hop
                            if(dir == 'N' && r != 0 && myBoard[r-1][c] == NULL){
                                myBoard[r-1][c] = myBoard[r][c];
                                myBoard[r][c] = NULL;
                                myBoard[r-1][c]->take_bigTurn();
                            }
                            else if(dir == 'S' && r != numRows-1 && myBoard[r+1][c] == NULL){
                                myBoard[r+1][c] = myBoard[r][c];
                                myBoard[r][c] = NULL;
                                myBoard[r+1][c]->take_bigTurn();
                            }
                            else if(dir == 'E' && c != numColumns-1 && myBoard[r][c+1] == NULL){
                                myBoard[r][c+1] = myBoard[r][c];
                                myBoard[r][c] = NULL;
                                myBoard[r][c+1]->take_bigTurn();
                            }
                            else if(dir == 'W' && c != 0 && myBoard[r][c-1] == NULL){
                                myBoard[r][c-1] = myBoard[r][c];
                                myBoard[r][c] = NULL;
                                myBoard[r][c-1]->take_bigTurn();
                            }
                            action = true;
                        }
                        else if(word == "left"){ //left
                            action = true;
                        }
                        else if(word == "right"){ //right
                            action = true;
                        }
                        else if(word == "infect"){ //infect
                            if(dir == 'N' && r != 0 && myBoard[r-1][c] != NULL && !myBoard[r][c]->sameSpecies(*(myBoard[r-1][c]))){
                                myBoard[r][c]->infect(*(myBoard[r-1][c]));
                            }
                            else if(dir == 'S' && r != numRows-1 && myBoard[r+1][c] != NULL && !myBoard[r][c]->sameSpecies(*(myBoard[r+1][c]))){
                                myBoard[r][c]->infect(*(myBoard[r+1][c]));
                            }
                            else if(dir == 'E' && c != numColumns-1 && myBoard[r][c+1] != NULL && !myBoard[r][c]->sameSpecies(*(myBoard[r][c+1]))){
                                myBoard[r][c]->infect(*(myBoard[r][c+1]));                         
                            }
                            else if(dir == 'W' && c != 0 && myBoard[r][c-1] != NULL && !myBoard[r][c]->sameSpecies(*(myBoard[r][c-1]))){
                                myBoard[r][c]->infect(*(myBoard[r][c-1]));
                            }
                            action = true;
			    myBoard[r][c]->take_bigTurn();
                        }
                        else if(word == "if_empty"){ //if_empty n
                            getline(stream, word, ' ');
                            int n = atoi(word.c_str());
                            if(dir == 'N' && (r == 0 || myBoard[r-1][c] == NULL)){
                                myBoard[r][c]->next_instruction(n);
                            }
                            else if(dir == 'S' && (r == numRows-1 || myBoard[r+1][c] == NULL)){
                                myBoard[r][c]->next_instruction(n);
                            }
                            else if(dir == 'E' && (c == numColumns-1 || myBoard[r][c+1] == NULL)){
                                myBoard[r][c]->next_instruction(n);
                            }
                            else if(dir == 'W' && (c == 0 || myBoard[r][c-1] == NULL)){
                                myBoard[r][c]->next_instruction(n);
                            }
                        }
                        else if(word == "if_wall"){
                            
                            getline(stream, word, ' ');
                            int n = atoi(word.c_str());
                            if(dir == 'N' && r == 0){
                                myBoard[r][c]->next_instruction(n);
                            }
                            else if(dir == 'S' && r == numRows-1){
                                myBoard[r][c]->next_instruction(n);
                            }
                            else if(dir == 'E' && c == numColumns-1){
                                myBoard[r][c]->next_instruction(n);
                            }
                            else if(dir == 'W' && c == 0){
                                myBoard[r][c]->next_instruction(n);
                            }
                        }
                        
                        else if(word == "if_random"){ //if_random n
                        }
                        
                        else if(word == "if_enemy"){ //if_enemy n
                            getline(stream, word, ' ');
                            int n = atoi(word.c_str());
                            if(dir == 'N' && r != 0 && myBoard[r-1][c] != NULL && !myBoard[r][c]->sameSpecies(*(myBoard[r-1][c]))){
                                myBoard[r][c]->next_instruction(n);
                            }
                            else if(dir == 'S' && r != numRows-1 && myBoard[r+1][c] != NULL && !myBoard[r][c]->sameSpecies(*(myBoard[r+1][c]))){
                                myBoard[r][c]->next_instruction(n);
                            }
                            else if(dir == 'E' && c != numColumns-1 && myBoard[r][c+1] != NULL && !myBoard[r][c]->sameSpecies(*(myBoard[r][c+1]))){
                                myBoard[r][c]->next_instruction(n);                     
                            }
                            else if(dir == 'W' && c != 0 && myBoard[r][c-1] != NULL && !myBoard[r][c]->sameSpecies(*(myBoard[r][c-1]))){
                                myBoard[r][c]->next_instruction(n);
                            }
                        }
                        
                        else if(word == "go"){ //go n
                        }
                        
                        else{
                            assert(0); //illegal instruction
                        }
                        //execute string
                        //if it's not an action instruction, execute creature's next instruction
                    } //end of while(action == false)
                } //end of if(myBoard[r][c] != NULL && round != myBoard[r][c]->turn)
            } //end of for(int c = 0; c < numColumns; c++)
        } //end of for( int r = 0; r < numRows; r++)
        
        for( int r = 0; r < numRows; r++){
            for(int c = 0; c < numColumns; c++){
                //cout << "thunder...";
                //myBoard[r][c]->turn = true;
                if(myBoard[r][c] != NULL) myBoard[r][c]->take_bigTurn_reset();
                //cout << "...flash" << endl;
            }
        }
    }

// -----
// print
// -----

/**
* Print the current state of the game. 
*/

    void print(ostream& stream){ 
        stream << "Turn = " << round << "." << endl;
        stream << "  ";
        for(int c = 0; c< numColumns; c++){
            stream << (c % 10);
        }
        stream << endl;
        for(int r = 0; r < numRows; r++){
            stream << (r % 10) << " ";
            for(int c = 0; c < numColumns; c++){
                if(myBoard[r][c] == NULL) stream << ".";
                else stream << myBoard[r][c]->species;
            }
            stream << endl;
        }
        stream << endl;
    }
    
};

/* UML: 
[Grid|-numColumns : int;-numRows : int;-round : int|+turn();+print(stream : ostream&);+deployCreature(newCreature : Creature&;r : int;c : int)]<>1-has 0..*>[Creature|-species : char;-direction : char;-programCounter : int;-turn : int|+take_bigTurn();+take_turn() : string;+turnLeft();+turnRight();+sameSpecies(him : Creature&) : bool;+infect(target : Creature&);+next_instruction(n : int)]
*/
