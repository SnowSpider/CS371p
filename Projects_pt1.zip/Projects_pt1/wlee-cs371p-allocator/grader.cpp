/* Grading program for CS371P Project 3: Allocator.
 * Author: Alon Farchy afarchy@cs.utexas.edu
 * Compile with:
 *   g++ -g -DNDEBUG -ansi -pedantic -Wall grader.cpp -o grader
 */

#include <cstdio>
#include <cstdlib>
#include "Allocator.h"

#define TEST(x) try { possible++; if((x) != 0) points++; } catch(...) {}
#define TEST_EX(x) try { possible++; x; } catch(std::bad_alloc& e) { points++; } catch(...) {}
#define REWARD(x) possible += x; points += x

template<typename T, std::size_t S>
class W {
public:
    typedef Allocator<T, S> allocator;
    //typedef std::allocator<T> allocator;
};

static int points;
static int possible;
static int constructors;
static int copy_constructors;
static int destructors;

class Foo {
public:
    int x;
    Foo() { constructors++; }
    explicit Foo(int y) { x = y; constructors++; }
    Foo(const Foo& other) { x = other.x; copy_constructors++; }
    ~Foo() { destructors++; }
};

// 1 Points
void test_constructor() {
    W<Foo, 100>::allocator foo_alloc;
    TEST(constructors == 0);
}

// 5 Points
void test_allocate() {
    W<Foo, 100>::allocator alloc_100;
    // 92 remaining

    TEST(alloc_100.allocate(5));
    // 68 remaining

    TEST_EX(alloc_100.allocate(17));
    // Exception

    TEST(alloc_100.allocate(16))
    // 0 Remaining

    TEST_EX(alloc_100.allocate(1));
    // Exception

    TEST(constructors == 0);
}

// 4 Points
void test_construct() {
    W<Foo, 100>::allocator alloc_100;

    Foo* p;
    const Foo f(1234);
    p = alloc_100.allocate(2);
    alloc_100.construct(p, f);
    alloc_100.construct(p+1, *p);
    TEST(constructors == 1);
    TEST(copy_constructors == 2);
    TEST(p[0].x == 1234);
    TEST(p[0].x == p[1].x);
}

// 1 Points
void test_destroy() {
    W<Foo, 100>::allocator alloc_100;
    Foo f(1234);
    Foo* p = alloc_100.allocate(2);
    alloc_100.construct(p, f);
    alloc_100.construct(p+1, f);
    alloc_100.destroy(p);
    alloc_100.destroy(p+1);

    TEST(destructors == 2);
}

// 4 Points
void test_deallocate() {
    // 5 items = 4*2*5 + 5*4 = 60
    W<Foo, 60>::allocator alloc_60;
    Foo* p1 = alloc_60.allocate(1);
    Foo* p2 = alloc_60.allocate(1);
    Foo* p3 = alloc_60.allocate(1);
    Foo* p4 = alloc_60.allocate(1);
    Foo* p5 = alloc_60.allocate(1);

    alloc_60.deallocate(p1, 1); 
    Foo* p6 = alloc_60.allocate(1);
    TEST(p1 == p6);

    alloc_60.deallocate(p4, 1);
    alloc_60.deallocate(p5, 1);
    Foo* p7 = alloc_60.allocate(2);
    TEST(p7 == p4);
    
    alloc_60.deallocate(p3, 1);
    alloc_60.deallocate(p2, 1);
    alloc_60.deallocate(p7, 2);
    Foo* p8 = alloc_60.allocate(4);
    TEST(p8 == p2);

    alloc_60.deallocate(p8, 4);
    alloc_60.deallocate(p1, 1);
    Foo* p9 = alloc_60.allocate(13);
    TEST(p1 == p9);
}

#define NUM_TESTS 5

void(*tests[NUM_TESTS])(void) = {
    test_constructor,
    test_allocate,
    test_construct,
    test_destroy,
    test_deallocate
};

const char *test_names[NUM_TESTS] = {
    "Allocator() Test",
    "allocate() Test",
    "construct() Test",
    "destroy() Test",
    "deallocate() Test"
};

int main() {
    int total = 0;
    for (int i = 0; i < NUM_TESTS; i++) {
        printf("%s: ", test_names[i]);
        points = 0;
        possible = 0;
        constructors = 0;
        copy_constructors = 0;
        destructors = 0;
        try {
            tests[i]();
        }
        catch(...) {
            printf("Exception caught! ");
        }
        printf("%d/%d\n", points, possible);
        total += points;
    }
    printf("%d", total);
}

