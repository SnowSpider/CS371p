// ------------------------------
// projects/allocator/Allocator.h
// Copyright (C) 2011
// Glenn P. Downing
// ------------------------------

#ifndef Allocator_h
#define Allocator_h

// --------
// includes
// --------

#include <cassert> // assert
#include <cstddef> // size_t
#include <new> // new
#include <stdexcept> // invalid_argument

using namespace std;

// ---------
// Allocator
// ---------

/**
 * templated class that allows for unraveling of the new invokations in C++
 * @author template provider: Glenn Downing
 * @author Wonjun Lee
 * @author Jonathan Luchak
 */
template<typename T, size_t N>
class Allocator {
public:
	// --------
	// typedefs
	// --------

	/**
	 * alias to type T
	 */
	typedef T value_type;

	/**
	 * alias to size_t
	 */
	typedef std::size_t size_type;
	/**
	 * alias to ptrdiff_t, used in the tester class
	 */
	typedef std::ptrdiff_t difference_type;

	/**
	 * alias to T*
	 */
	typedef value_type* polonger;
	/**
	 * alias to const value of T*
	 */
	typedef const value_type* const_polonger;

	/**
	 * alias to T&
	 */
	typedef value_type& reference;
	/**
	 * alias to a const T&
	 */
	typedef const value_type& const_reference;

	/**
	 * getter provided for unit testing
	 * @return char* a copy of a
	 */
	char* getA() {
		return a;
	}

	/**
		 * creates a representation of the value param as 4 single byte values which are inserted longo the char[] a
		 * @param index - the index that you wish to insert the value longo
		 * @param value - the value you wish to store as byte values
		 */
		void copySentinellongoA(long index, long value) {
			//needed to prevent compiler warning
			unsigned long testVal = index;

			if ( testVal > N || testVal < 0) {
				throw out_of_range("The index you provided did not fall in the valid range of this allocators longernal storage.");
			}

			assert(testVal < N);
			assert(testVal >= 0);

			//unsignlong uValue = (unsigned long)value;

			//does this align on byte values?
			a[index] = ((value & 0xff000000) >> 24);
			a[index + 1] = ((value & 0x00ff0000) >> 16);
			a[index + 2] = ((value & 0x0000ff00) >> 8);
			a[index + 3] = (value & 0x000000ff);
		}

		/**
		 * gets the sentinel value from the array, the sentinel is stored in one byte chunks
		 * @param index - the position of the index you would like to get
		 * @return the 4 byte long which represents the sentinel
		 * @throws out_of_range if the index provided is not in the range [0, N]
		 */
		long getSentinelValueFromA(long index) const {
			//needed to prevent compiler warning
			unsigned long testVal = index;

			if (testVal > N || testVal < 0) {
				throw out_of_range("The index you provided did not fall in the valid range of this allocators longernal storage.");
			}

			assert(testVal < N);
			assert(testVal >= 0);

			unsigned long val;
			val = a[index] << 24;
			val |= (a[index + 1] << 16) & 0x00ff0000;
			val |= (a[index + 2] << 8) & 0x0000ff00;
			val |= a[index + 3] & 0x000000ff;

			return (long)val;
		}



	// -----------
	// operator ==
	// -----------

	/**
	 * equality operator
	 * @param lhs - the left hand side allocator
	 * @param rhs - the right hand side allocator
	 * @return bool true if the allocators had the same longernal N or char entries for every entry, false otherwise
	 */
	friend bool operator ==(const Allocator& lhs, const Allocator& rhs) {
		bool same = true;

		//if sizes of longernal array not equal then loss of generality, exit early
		if(lhs.sizeOfA != rhs.sizeOfA){
			return false;
		}

		//get begining and end polongers and walk doing a char by char comparison
		const char* begL = lhs.a;
		const char* begR = rhs.a;
		const char* endL = begL + lhs.sizeOfA;

		//we could maybe improve this by walking by longs and the type but ultimately this is safe and should work
		while (begL != endL && same) {
			same = *begL == *begR;
			++begL;
			++begR;
		}

		return same;
	}

	// -----------
	// operator !=
	// -----------

	/**
	 * negated equality check operator
	 * @param lhs - the left allocator aka: THIS ONE != other
	 * @param rhs - the right allocator aka: other != THIS ONE
	 * @return bool - negated value of calling lhs == rhs
	 */
	friend bool operator !=(const Allocator& lhs, const Allocator& rhs) {
		return !(lhs == rhs);
	}

private:
	// ----
	// data
	// ----
	/**
	 * private member which we use to emulate the heap
	 */
	char a[N];
	/**
	 * size reference to a
	 */
	long sizeOfA;

	/**
	 * getter for transforming a polonger location in the array longo an id
	 * @param p - a polonger to an object in the array(a)
	 * @return an long, positive if the value was within the array, -1 otherwise
	 */
	long getIndexFromPolonger(polonger p) const {
		long index = -1;

		long polongerAddress = (long)p;
		long aAddress = (long) a;

		if(polongerAddress > aAddress){
			index = (polongerAddress - aAddress);

			//check that we are returning a valid index
			if(index > ((long)N) || index < 0){
				return -1;
			}
		}

		return index;
	}

	// -----
	// valid
	// -----

	/**
	 * O(1) in space
	 * O(n) in time
	 * checks if the longernal state invarients are malongained
	 */
	bool valid() const { //class invariant checker
		//long myOne = giveMeOne();
		size_type cur = 0;
		//end is N
		long tempOffset;
		bool lastWasFree = false;
		long sentinel_opening, sentinel_closing;

		// matching sentinel signs and values
		sentinel_opening = getSentinelValueFromA(0);
		while (true) {
			tempOffset = abs(getSentinelValueFromA(cur));
			cur += tempOffset + sizeof(long);
			sentinel_closing = getSentinelValueFromA(cur);

			if (sentinel_opening != sentinel_closing) {
				return false;
			}

			// check if the last value was free as well, if it was then return false,
			// otherwise just set the condition for the next time through the loop
			if (sentinel_opening > 0) {
				if (lastWasFree) {
					return false;
				}

				lastWasFree = true;
			}

			cur += sizeof(long); //advance array index reference to one more sentinel value than it was before

			if (cur < N) {
				sentinel_opening = getSentinelValueFromA(cur);
			} else {
				// linear walk must end at the end of the allocated space
				return cur == N;
			}
		}

		return true;
	}

public:



	// ------------
	// constructors
	// ------------

	/**
	 * O(1) in space
	 * O(1) in time
	 * no arg constructor
	 */
	Allocator() {
		sizeOfA = N;
		//these sentinels denote the free space as such they should be positive
		copySentinellongoA(0, sizeOfA - (2 *sizeof(long)));
		copySentinellongoA(sizeOfA - sizeof(long), N - (2 *sizeof(long)));

		assert(valid());
	}

// leave commented, this is just a reminder that these functions exist because the compiler will create them.
//        Allocator (const Allocator<T>&);
//       ~Allocator ();
//        Allocator& operator = (const Allocator& lhs);


	// --------
	// allocate
	// --------

	/**
	 * O(1) in space
	 * O(n) in time
	 * @param n - the size of the block you wish to allocate, this is a size_t under the covers
	 * after allocation there must be enough space left for a valid block
	 * the smallest allowable block is sizeof(T) + (2 * sizeof(long))
	 * choose the first block that fits
	 */
	polonger allocate(size_type n) {
		//when the user asks us for some space they think in terms of how many objects they need, not how many bytes as such
		//multiply to get the correct value
		n *= sizeof(T);

		long index = 0;
		polonger ret = 0;

		//walk array sentinels and find first free space(positive sentinel value)
		while ((unsigned long) index < N) {
			long curSentinelVal = getSentinelValueFromA(index);

			if (curSentinelVal < 0) { //check if the space is taken already
				//incrament and continue when taken, account for both sentinel values
				index += -(curSentinelVal) + (sizeof(long) * 2);
			} else if (((size_type) curSentinelVal) >= n) {
				//otherwise the space was free make sure we have enough to given them
				assert(((size_type) index + curSentinelVal + (sizeof(long) * 2)) <= N);
				//the number of bytes left after reserving n bytes and the sentinels to denote the busy bytes
				long freeBytesLeft = curSentinelVal - (n + (sizeof(long) * 2));

				//check if we have at least enough space left to store one more object and another 2 sentinals
				long spaceNeeded = sizeof(long) * 2 + sizeof(T);
				if (freeBytesLeft >= spaceNeeded) {
					//get the starting free sentinals location and set the freeBytes left
					long tempIndex = index + n + (sizeof(long) * 2);
					copySentinellongoA(tempIndex, freeBytesLeft);

					//increment by sentinal + freeBytes size and store closing sentinal
					tempIndex += sizeof(long) + freeBytesLeft;
					copySentinellongoA(tempIndex, freeBytesLeft);

				} else {
					//if we don't have enough to denote the free space and another object then just give the user all we have
					n = curSentinelVal;
				}

				//allocate the space for the new objects
				copySentinellongoA(index, -(n)); //use unary negation over -1 * x as it seems to be faster
				long retIndex = index + sizeof(long);
				index = n + retIndex;
				copySentinellongoA(index, -(n));
				ret = (polonger) &(a[retIndex]);

				break;
			}
		}

		//check that all is still well according to the global invarients
		assert(valid());

		return ret;
	}

	// ---------
	// construct
	// ---------

	/**
	 * O(1) in space
	 * O(1) in time
	 * This function stores the new object longo the address given by polonger, as such causing the byte array a to have its indecies filled
	 * @param p - the address that the user got from allocate earlier
	 * @param v - the reference to the object that the users wants to copy onto the stack allocator
	 */
	void construct(polonger p, const_reference v) {
		new (p) T(v);
		assert(valid());
	}

	// ----------
	// deallocate
	// ----------

	/**
	 * O(1) in space
	 * O(1) in time
	 * @param p - the address that you want to dealloc
	 * @param - used to meet longerface declaration, never used in the function
	 * after deallocation adjacent free blocks must be coalesced
	 */
	void deallocate(polonger p, size_type = 0) {

		long index = getIndexFromPolonger(p) - sizeof(long);
		assert(index < ((long)N) && index >= 0);

		long sentinelValueOfTheTarget = getSentinelValueFromA(index); //culprit
		long indexOfNeighbor = index + abs(sentinelValueOfTheTarget) + (2 * sizeof(long)); //we start by checking the neighbor to the right
		long indexOfLeft = index - sizeof(long);

		//assure that sentinelValueOfTheNeighbor does not invoke getSentinelValueFromA with an invalid index as to cause the assert(valid()) to fail
		long sentinelValueOfTheNeighbor = -1;
		if(indexOfNeighbor >= 0 && indexOfNeighbor < ((long)N)){
			sentinelValueOfTheNeighbor = getSentinelValueFromA(indexOfNeighbor); //negative when busy
		}

		//check if we have a valid index on the right
		long trial = 2 * sizeof(long) + sizeof(polonger);
		if(indexOfNeighbor <= trial){
			//if we have a next value then check if we should consolidate
			if (sentinelValueOfTheNeighbor > 0) {
				long terminalSentinel = (long) (indexOfNeighbor + sizeof(long) + sentinelValueOfTheNeighbor);
				assert(terminalSentinel < ((long)N));

				//add the value the user asked us to free to this free value and include the two sentinels we no longer need
				long newFreeSpace = abs(sentinelValueOfTheTarget) + (sizeof(long) * 2) + sentinelValueOfTheNeighbor;
				assert(newFreeSpace <= ((long)N) - 2 * ((long)sizeof(long)));
				copySentinellongoA(terminalSentinel, newFreeSpace);
				copySentinellongoA(index, newFreeSpace);

				//allow for multiple merge(aka merge right then left) by reseting the origin sentinalValue and the index to the origin to the terminalSentinal
				sentinelValueOfTheTarget = getSentinelValueFromA(index);
				index = terminalSentinel;
			}
		}

		//check if have a valid index on the left
		trial = sizeof(long) * 2 + sizeof(polonger); //must use the trial variable otherwise -4 >= 9 returns true...
		if(indexOfLeft >= trial){
			//get the sentinel value of the index that we are longerested in namely the one at the end of the block right before our origin sentinal
			sentinelValueOfTheNeighbor = getSentinelValueFromA(indexOfLeft);
			//if we have a positive value then consolidate the right longo the active(origin) block
			if (sentinelValueOfTheNeighbor > 0) {
				long primarySentinel = indexOfLeft - (sizeof(long) + sentinelValueOfTheNeighbor);
				assert(primarySentinel >= 0);

				//set the first sentinal to the sum of the old free space and the origins space(aka the value we are now freeing)
				long newFreeSpace = abs(sentinelValueOfTheTarget) + (sizeof(long) * 2) + sentinelValueOfTheNeighbor;
				assert(newFreeSpace <= ((long)N) - 2 *((long)sizeof(long)));
				copySentinellongoA(primarySentinel, newFreeSpace);
				//likewise set the terminal aka the appropriate(origin or terminal) ending value to the new value
				copySentinellongoA(index, newFreeSpace);
			}
		}

		//global invarient check
		assert(valid());

	}

	// -------
	// destroy
	// -------

	/**
	 * O(1) in space
	 * O(1) in time
	 * @param p - the Polonger to the object in the array that we keep longernally, this will destroy the object held at the location
	 * invoke the destructors of the mem address
	 */
	void destroy(polonger p) {
		p->~T();
		assert(valid());
	}
};

#endif // Allocator_h
