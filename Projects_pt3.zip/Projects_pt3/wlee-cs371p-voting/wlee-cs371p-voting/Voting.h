// --------------------------------
// Voting
// February 2012
// Author: Wonjun Lee, John Richter
// --------------------------------

/*

To configure Doxygen:
% doxygen -g
That creates the file "Doxyfile".
Make the following edits:
EXTRACT_ALL = YES
EXTRACT_PRIVATE = YES
EXTRACT_STATIC = YES
GENERATE_LATEX = NO

To document the program:
% doxygen Doxyfile

*/

// --------
// includes
// --------

#include <cassert> // assert
#include <iostream> // endl, istream, ostream
#include <string>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <ctime>
#include <cstdlib>
#include <fstream>

using namespace std;

#define SIZE 1000000
#define MAXNAME 80
#define MAXCAND 20
#define MINCAND 1
#define MAXBALLOT 1000
#define MINBALLOT 1

// ----------
// printArray
// ----------

/**
* Prints the content of an int array in a single line. 
* @param arg[] the array of interest
* @param length the length of the array
*/

void printArray (int arg[], int length) { // for debugging.
  for(int n=0; n<length; n++)
  cout << arg[n] << " ";
  cout << "\n";
}

// ---------------
// make1DIntArray
// ---------------

/**
* Constructs a single dimensional int array of arbitrary size
* @param size the number of elements in int
*/
int* make1DIntArray(int size){
    int* array = new int[size];
    for(int i=0; i<size; i++) {
        array[i] = 0; // Initialize all elements to zero.
    }
    return array;
}

// ---------------
// make2DIntArray
// ---------------

/**
* Constructs a 2-dimensional int array of arbitrary dimensions
* @param numRow the number of rows in int
* @param numColumn the number of columns in int
*/
int** make2DIntArray(int numRow, int numColumn) {  
    int* array_data = new int[numRow*numColumn];
    int** array = new int*[numRow];
    for(int i = 0; i < numRow; i++) {
        array[i] = array_data + numColumn*i;
        for(int j = 0; j<numColumn; j++){
            array[i][j] = 0; // Initialize all elements to zero.
        }
    }
    return array;  
}

// ---------------
// make2DCharArray
// ---------------

/**
* Constructs a 2-dimensional char array of arbitrary dimensions
* @param numRow the number of rows in int
* @param numColumn the number of columns in int
*/
char** make2DCharArray(int numRow, int numColumn) {  
    char* array_data = new char[numRow*numColumn];
    char** array = new char*[numRow];
    for(int i = 0; i < numRow; i++) {
        array[i] = array_data + numColumn*i;
        for(int j = 0; j<numColumn; j++){
            array[i][j] = NULL;
        }
    }
    return array;
}

// -----------------
// voting_markLosers
// -----------------

/**
* Updates the cache candStates which stores the state of each candidate: 1 for a loser, 0 for a survivor
* @param numCand the number of candidates in int
* @param numBallot the number of ballots in int
* @param candVotes cache storing the votes for candidates
* @param candStates cache storing the state of candidates
*/
void voting_markLosers(int numCand, int numBallot, int* candVotes, int* candStates){ // updates the candStates array.
    int min = numBallot;
    for(int i=0; i<numCand; i++){ //find the min number of votes.
        if(candStates[i] == 0 && candVotes[i] < min){
            min = candVotes[i];
        }
    }
    int max = 0;
    for(int i=0; i<numCand; i++){ //find the max number of votes.
        if(candStates[i] == 0 && candVotes[i] > max){
            max = candVotes[i];
        }
    }
    if(max != min){
        //min has been found.
        //cout << "min = " << min << endl;
        //int numLosers; // This must be equal to numCand-1 for the case to end.
        for(int i=0; i<numCand; i++){
            if(candStates[i] == 0 && candVotes[i] == min){
                candStates[i] = 1; // This candidate is dropped out. His votes won't be counted.
            }
        } 
    }
}

// -----------
// voting_done
// -----------

/**
* Examine the two caches to determine if the case is concluded
* @param numCand the number of candidates in int
* @param numBallot the number of ballots in int
* @param candVotes cache storing the votes for candidates
* @param candStates cache storing the state of candidates
* @return true if the case is concluded, false otherwise
*/
bool voting_done(int numCand, int numBallot, int* candVotes, int* candStates){
    int max = 0;
    int indexWinner = -1;
    for(int i=0; i<numCand; i++){ //find someone with >50%
        if(candStates[i] == 0){
            if(candVotes[i] > max){
                max = candVotes[i];
                indexWinner = i;
            }
        }
    }
    if(max > numBallot/2){
        for(int i=0; i <numCand; i++) {
            if(candStates[i]==0 && i!=indexWinner)
                candStates[i]=1;
        }
        // eliminate everyone who failed to win
        return true;
    }
    int number;
    for(int i=0; i<numCand; i++){
        if(candStates[i] == 0){
            number = candVotes[i];
            break;
        }
    }
    int temp;
    for(int i=0; i<numCand; i++){
        if(candStates[i] == 0){
            temp = candVotes[i];
            if(temp != number) return false;
        }
    }
    //only comes here if they tied
    int sum = 0;
    for(int i = 0; i< numCand; i++) {
        if(candStates[i]==0) {
            sum+=candVotes[i];
        }
    }
    if(sum==numBallot)
        return true;
    else 
        return false;
}

bool firstRound=true;

// ------------------
// voting_solveHelper
// ------------------

/**
* Examine cache_ballot and update candVotes and candStates recursively until the case is concluded.
* @param numCand the number of candidates in int
* @param numBallot the number of ballots in int
* @param candidates cache storing the candidate names in string
* @param cache_ballot cache storing the input ballots
* @param candVotes cache storing the votes for candidates
* @param candStates cache storing the state of candidates
*/
void voting_solveHelper(int numCand, int numBallot, char** candidates, int**  cache_ballot, int* candVotes, int* candStates){
    for(int i=0; i<numBallot; i++){
        int candID = cache_ballot[i][0] - 1;
        int k = 1;
        while(candStates[candID] == 1 && k < numCand){
            candID = cache_ballot[i][k] - 1;
            k ++;
        }
        candVotes[candID] ++;
    }
    if(firstRound) {
        for(int i=0; i<numCand; i++){ //elimnates candidates with 0 votes.
            if(candVotes[i] == 0){
                candStates[i] = 1;
            }
        }
        firstRound = false;
    }
    voting_markLosers(numCand, numBallot, candVotes, candStates); //side effect: update candStates
    // If all surviving candidates have the same number of vote, halt. Also applies when there is ONE survivor.
    bool flag = voting_done(numCand, numBallot, candVotes, candStates);
    if(!flag){ 
        //clear votes
        for(int i =0; i< numCand; i++) {
            candVotes[i]=0;
        }
        voting_solveHelper(numCand, numBallot, candidates, cache_ballot, candVotes, candStates);
    }
}

// ------------------
// voting_solve
// ------------------


/**
* Solves a single case.
* @param numCand the number of candidates in int
* @param numBallot the number of ballots in int
* @param candidates cache storing the candidate names in string
* @param cache_ballot cache storing the input ballots
* @return candStates cache storing the state of each candidate: 0 for losing, 1 for winning
*/
int* voting_solve(int numCand, int numBallot, char** candidates, int** cache_ballot){
    int* candVotes = make1DIntArray(numCand);
    int* candStates = make1DIntArray(numCand); //0 for winning, 1 for losing
    
    voting_solveHelper(numCand, numBallot, candidates, cache_ballot, candVotes, candStates);
    
    delete [] candVotes; candVotes = NULL;
    return candStates;
}

// ------------
// voting_print
// ------------

/**
* Prints the winners.
* @param numCand the number of candidates in int
* @param candidates cache storing the candidate names in string
* @param candStates cache storing the state of candidates
*/
void voting_print(int numCand, char** candidates, int* candStates){
    for(int i=0; i<numCand; i++){
        if(candStates[i] == 0){
            cout << candidates[i] << endl; //print the names of the winners
        }
    }
}

// -----------
// voting_read
// -----------

/**
* reads two ints into i and j
* @param r a std::istream
* @param i an int by reference
* @param j an int by reference
* @return true if that succeeds, false otherwise
*/
bool voting_read (std::istream& input) {
    string line;
    getline(input, line);
    int numCases = atoi(line.c_str()); //get the number of cases
    assert(numCases > 0);
    
    int numCand;
    int numBallot;
    int rank; // column pivot
    
    getline(input, line);
    for(int n = 0; n < numCases; n++){
        getline(input, line); //number of candidates
        numCand = atoi(line.c_str());
        assert(numCand > 0);
        char** candidates = make2DCharArray(numCand, MAXNAME);           
        for(int k = 0; k < numCand; k++){
            getline(input, line);
            strcpy (candidates[k], line.c_str()); //candidate name
        }
        int** cache_ballot = make2DIntArray(MAXBALLOT, numCand);
        numBallot = 0; 
        while(getline(input, line) && strcmp(line.c_str(), "") &&  numBallot<MAXBALLOT){
            string word;
            stringstream stream(line);
            rank = 0;
            while(getline(stream, word, ' ') && rank<numCand) {
                cache_ballot[numBallot][rank] = atoi(word.c_str());
                rank++; 
            }
            //cout << endl;
            numBallot++;
        }
        
        //Solve a case
        if(n != 0) cout << endl;
        int* candStates = voting_solve(numCand, numBallot, candidates, cache_ballot);
        voting_print(numCand, candidates, candStates);
        delete [] candidates; candidates = NULL;
        delete [] cache_ballot; cache_ballot = NULL;
        delete [] candStates; candStates = NULL;
    }
    return true;
}
