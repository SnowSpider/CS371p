Wonjun Lee
wl4337
John Richter
jdr3233
https://www.assembla.com/code/wlee-cs371p-voting/git/nodes/
http://code.google.com/p/jrichter-cs371p-voting/
